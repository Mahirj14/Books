[[interview]]  #questions 


**If you have 10 input files but only 2 are critical and need immediate processing , 
how would you configure and orchestrate spark jobs for the remaining 8 files ?**

--> To configure and orchestrate Spark jobs for processing a mix of critical (2) and non-critical (8) input files,
you can use job prioritization and queueing mechanisms.

Spark provides a way to prioritize jobs using job scheduling queues.
You can set job priorities when submitting Spark applications. 
In this case, you want to prioritize the jobs for the critical files. 
You can submit high-priority jobs for the critical files and lower-priority jobs for the non-critical files.

> FORD

how to delete duplicates
python code for finding non numeric value in payment column

data profiling
data checks

how to handle 100gb data
what is coleasc/repartision
aws scinario based Qiestion
ETL data warouhouse , data lake, data mart

> sociate general

- i have 6gb json file but spark executor size in 3gb so have can i read that file without executor size change
- df convert to json data

- you have to write python code for string and count seqential value s = "abcabbba" higest in sequence abc means count 3. if reapeat that not count
- create session,  read df, withcolumn

```python
df = spark.createDataFrame(data=data2,schema=schema)
```



>nexgensis

- brodcastjoin
```python

joined_df = df.join(brodcast(small_df), df.value == small_df.id)

joined_df =df.join(broadcasr(small_df), df.id == df.id)
```



freqency table/cross table


> ford round 2

- star/snowfalk
- scd2 scripting in sql
- sql joins(inner,left,right,full)
- pyspark window function
- copay? writeoff? 
- commulative marks 
- redshift? architecture ? 
- write in redshift database

> coditas

- nested json
- flatten expose
- json/xml formate
- json pyspark scenario


> Murck

You are provided access to a database with three tables. All SQL. Questions will be based on the below tables only.
- Employees (EmployeelD, FirstName, LastName, DepartmentID, ManagerID, JobTitle, Salary, HireDate) 
- Departments (DepartmentID, DepartmentName) 
- ProjectAssignments (ProjectID, EmployeelD, AssignmentDate) 

Question 1 -- The management team needs a report that lists each department along with the count of employees and the most recent project assignment date for each department. Write an SQL query that produces this report.

``` python
SELECT 
    d.DepartmentName,
    COUNT(e.EmployeeID) AS EmployeeCount,
    MAX(pa.AssignmentDate) AS MostRecentAssignmentDate
FROM 
    Departments d
LEFT JOIN 
    Employees e ON d.DepartmentID = e.DepartmentID
LEFT JOIN 
    ProjectAssignments pa ON e.EmployeeID = pa.EmployeeID
GROUP BY 
    d.DepartmentName;

```

	Q3 Write a query to find pairs of employees with the same job title but don't belong to department

SELECT 
    e1.EmployeeID AS EmployeeID1, 
    e1.FirstName AS FirstName1, 
    e1.LastName AS LastName1,
    e1.JobTitle,
    e2.EmployeeID AS EmployeeID2, 
    e2.FirstName AS FirstName2, 
    e2.LastName AS LastName2
FROM 
    Employees e1
JOIN 
    Employees e2 
ON 
    e1.JobTitle = e2.JobTitle
    AND e1.DepartmentID <> e2.DepartmentID
    AND e1.EmployeeID < e2.EmployeeID
ORDER BY 
    e1.JobTitle, e1.EmployeeID, e2.EmployeeID;


Q4-- HR team wants to identify Employees who may be under-compensated for making decisions related to salary adjustments and promotions. Write a query to find the employees who earn less than the average salary of their department

```

SELECT 
    e.EmployeeID,
    e.FirstName,
    e.LastName,
    e.DepartmentID,
    e.Salary,
    dept_avg.AverageSalary
FROM 
    Employees e
JOIN 
    (SELECT 
         DepartmentID, 
         AVG(Salary) AS AverageSalary
     FROM 
         Employees
     GROUP BY 
         DepartmentID) dept_avg
ON 
    e.DepartmentID = dept_avg.DepartmentID
WHERE 
    e.Salary < dept_avg.AverageSalary
ORDER BY 
    e.DepartmentID, e.Salary;

```

>python Q

Consider the following four data structures in Python: List, Tuple, Set, and Dictionary.
1. Provide a Python code snippet that demonstrates how to create and manipulate each data structure.
2. Explain the key differences between these data structures in terms of mutability ordering, and whether they allow duplicate elements.

Question 2 --Develop a Python program that accepts two sentences as input. Assign a score of +5 for each word that appears in both sentences and deduct I point for each missing word. Double the score if there are no missing words. Finally, calculate the total score.

Question 4-- Write a Python function named squared_odds that takes a list of integers as input and uses list comprehension to return a new list containing the squares of all the odd numbers in the input list. For example, if the input list is [1, 2, 3, 4, 5], the function should return [1, 9, 25].


> TCS

- glue dynamic frame
- large dataset but not reading already define memory setting and partition still
- parameter store --  system manager param store, secret manager
- secret manager
- dynamic frame
- how come multiple small file joined one - coleacs
- dynamic Vs. DF
- GetResolvedOption?

> TCS

- wt is checkpoint?  - resume job
- if accidently delete df how to recovery --- persist method
- IAM/cognito -- permission / authentication
- how to split df1 to df2 -- using split command
- pysaprk job failed how to check ? -- monitoring
- how to check which job is running late? -- Sparkui
- how to deploy code>> types?
- how to load s3 files from source
- max EC2 create in region ? --20
- capacity of s3 bucket ? -- 5TB




> how to create using rdd

 rdd = sc.parallelize(data)


>*Principal*

- what is size of table? which is main table?
- what is requirement / why they want to migrate aws?
- how to data is tranffered comeple how you get to know. ?
- how BI team can handle big data ? hv any optimization ?
- is parqet files are multiples ?
- sql joins
- 


> primary key column they dont have null