[[interview]]


*bio*

Hi there🖐️ ! Mahir this side

* Passionate AWS Data Developer
* Proven track record in designing and developing innovative solutions
* Deep understanding of AWS services: Lambda, API Gateway, DynamoDB, Kinesis, Cognito

* Confident in building scalable and cost-effective cloud architectures
* Years of experience in the industry
* Able to tackle complex problems with ease
* Interested in collaborating on the next big thing in cloud computing


Services : AWS Lambda, Redshift, RDS, Glue, API Gateway, EKS, S3, EC2, Kinesis, Step function, Athena, Cloudwatch, Quicksight, DMS, Talend, ETL

Languages: Pyspark, SQL, Shell scripting

Devops: Terraform

Tools: Snowflake, Apache Airflow, Kafka

Data Engineering : ETL, Data Warehouse, Big Data, Data Pipeline,
 Streaming Data, Data Lakes, Data Modeling, Data Governance, Data Quality


*formate*

Total Experience - 2.1 year
Relevant Experience - 2.1 year
Current CTC - 4LPA	
Expected CTC - 8-10LPA
Notice Period - 3 MONTHS (Negoiable)
Preferred Location - Pune or Bengaluru
Current Location - Bengaluru