- SQL
    
    - Aggregate functions - AVG, MIN, MAX, etc.
    - Joins - important! types of joins and their output.
    - Window functions - Ranking functions, LAG, LEAD
    - what is how do they work, how to create this and why is it used, pros and cons for the following:
        - CTEs
        - Views, Materialized views
        - Index - also types of indexes, index behind the scenes.
        - Partitioning - types of partitioning
        - Normalization / Denormalization - rarely asked but important
- Data Warehousing (DW) and ETL
    
    - Star vs Snowflake Schema
    - DB vs DW vs Data lake, when to use appropriately
    - Choosing Columnar vs row oriented Databases
    - Facts, Dimensions - understanding, examples
    - Steps to implement a Data warehouse (for example in Bigquery)
    - Best practices for DW, reporting
    - Slowly changing dimensions
    - Handling duplicate records, inconsistencies in data.
    - Understanding ETL vs ELT process, data cleaning, ingestion techniques.
- Spark
    
    - Understading Architecture
    - YARN basics
    - Sparkcontext, session, worker, task, job, stage, etc
    - Spark dataframes, actions, transformations, reading and writing data, specifying schema options
    - Repartioning vs Coalesce
    - Partioning
    - Handling OOM error in spark
    - Broadcast variables, broadcast joins
    - Best practices of Spark, best tuning practices
    - Different persisting strategies in spark
- Cloud experience
    
    - Not much questions but it is vital to have an idea on different big data tools and services available in any one Cloud platform and their use cases.
    - Most commonly used services in Cloud for Data systems
        - AWS - S3, Redshift, Glue, RDS
        - GCP - Cloud Storage, Bigquery, CloudSQL, Dataflow [for streaming]
- Linux skills - I think this is also a very important and basic skill requirement
    

> Other skills to learn to become a better a niche Data Engineer, if have the above mentioned topics covered, check these out:

- Orchestration tool - Airflow [slowly becoming a must have skill]
- Streaming data - Spark Streaming / Flink
- Pubsub systems like Kafka
- NoSQL databases - MongoDB, Elasticsearch, Cassandra, etc.
- System Design for Big Data



## AMAZON

Behaviourial : 4 Leadership Question  
a. Tell me when you said no to customer and how you handle it  
b. Tell time when you helped the team mate who is not able to deliver the work  
c. Tell me the approach you took which benfit the organiztion.  
d. Tell me the most difficult project you handled.

ETL :  
Design a Ingestion Pipeline which can scale to consume any number of excel/csv file landing on S3 . For example currently consuming 500 what if it have 2000 tommrrow.Define your approach.

Python:  
[https://leetcode.com/problems/find-the-difference/](https://leetcode.com/problems/find-the-difference/)

SQL :  
A seller on amazon seller wants to see his/her total products and total revenue per day.Design a data model and which data modeling technique you pick (dimensional or ER model) for same and write the sql for it.

What is Index and what purpose they serve? What consideration to keep in mind while defining index .

What is difference between views,temp table and staging table.