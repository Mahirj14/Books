- small pieces of information are grouped together to create a meaningful whole.

![[chunking.png]]

## Types of Chunking Strat

>****Fixed-size Chunking****
- Divides the text into chunks of a predetermined, fixed size (e.g. 256 tokens)
- Can optionally include some overlap between chunks to preserve context
- Character Text Splitter

>****Specialized Chunking****
- Tailors the chunking process to preserve the structure of specific content formats like Markdown or LaTeX
- Splits the text based on recognized syntax and formatting elements

>****Recursive Chunking****
- Recursively divides the text into smaller chunks until a minimum chunk size is reached
- Helps maintain the inherent structure and semantics of the original text

>****Document-Specific Chunking****
- Creates chunks that align with the logical sections of a document, like paragraphs or subsections
- Preserves the original organization and flow of the content

>****Semantic Chunking****
- Groups together sentences or passages with high semantic similarity
- Focuses on maintaining the overall meaning and context of the text

>****Token-based Chunking****
- Splits the text based on a target number of tokens per chunk
- Ensures the chunks adhere to any token limits of the downstream language model

>****Agent-based Chunking****
- Leverages an AI agent to dynamically determine appropriate chunk boundaries
- Aims to mimic how humans would naturally chunk information


![[Pasted image 20240718125338.png]]

