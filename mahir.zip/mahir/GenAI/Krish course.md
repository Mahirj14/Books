
> type of creating virtual environment

```python
python -m venv myenv

myenv/scripts/activate
```

```
pip install virtual env

virtual env -p python myenv

myenv/scripts/activate

```

```
conda create -p venv1 python==3.10
```