 - API not hitting --
- resource running out 
- max try reach out
- error 404
- libraries not installed
- ''pip freeze > requirements.txt''
- while running on machine code run fine but while deplyoment give openai_base_api error
    - so the solution is about version. use proper version accross all frmaworks like openai, langchai,  older/version

> soultionn deplyoed on azure and VM is running obsolutly fine but solution link is not working

- did Restart
- change port number

_Governance ???_
explainngable AI ?? research 

fine tuning


 >heluucination
 
 - low temp
 - try few shot prompting
 - fine tune

Named Entity Recognition (NER) >>>> Maximum Overlap Prompts

Use of Top-p Sampling

Token-Level Overlap