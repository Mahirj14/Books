
> ESG Chatbot

Environmental sustainability report

upload PDF > extract text using lungchain > do chunking  > store data in vector DB > user search via input Q. > that search related happen in vector DB > output

------------------------

> NLP to SQL converter
![[NLP-SQL.png]]

user > prompting >UI(streamlit) > sagamaker(claude model) > generated sql query > check in aws Rds > output

-------------------


>Text to image using fusion model ( Multimodel)


![[Multimodel.png]]

image+ text >amazon Bedrock(titan model) >vector DB> KNN > output

--------

> MarCom 

![[MarCom.png]]
Short and long message for Marketing campaign like: Invite, email, teaser, replay, reminder, leadership message
- GPT 3.5 Turbo 5k token
- Llama LLM 3

>internal 

- invite email (teaser,replay,reminder,invite)
- short message (teaser,replay,reminder,invite)
- niraj short note
- talent article

> external 

- web page
- blog
- social media mssg
- my comapny mssg
- client emailer


> CHALLENGES

- API not heating
- resource running out
- max try reach out
- error 404
- libraries not installed
- hellucination
- temp o.o
- chunking?