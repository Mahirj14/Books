![[LLM.png]]

 
 >GPT 3.5 / 4O
 

![[gpt 3-4.png]]
 
 > Google Gemini
 
 > CLAUDE Sonnet
 
 > Microsoft edge copilot
 
 > Perplexity
 
 > grok ( twitter)
 
 > mistral AI
 
 > Agents?
 
 > Falcon, LLaMA, Cohere




![[Pasted image 20240718112727.png]]


![[llm graph.png]]

image gen -- dalle E, stability defusation 