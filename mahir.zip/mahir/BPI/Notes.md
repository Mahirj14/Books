

## LangChain & Git 

LangChain is a framework for building applications with large language models (LLMs) by chaining interoperable components. It provides a flexible way to build context-aware, reasoning applications that leverage a company's data and APIs[4]. 

Git is a distributed version control system used for tracking changes in source code during software development. It allows multiple developers to collaborate on a project by managing and tracking changes to files[1]. 

To use LangChain with Git, you can: 

- Store your LangChain code in a Git repository for version control and collaboration 

- Use Git to manage changes and track issues related to your LangChain application 

- Integrate Git with your LangChain development workflow for seamless collaboration 

##LangGraph 

LangGraph is a framework for building controllable, agentic workflows with LangChain. It provides a way to create agents that can reason about tasks, break them down into subtasks, and execute them using LLMs and other components[4]. 

Key features of LangGraph include: 

- Task decomposition and planning 

- Reasoning about task execution 

- Incorporating external data and APIs 

- Asynchronous task execution 

## MyPy 

MyPy is a static type checker for Python that helps catch type-related errors early in the development process. It can be used with LangChain to ensure type safety and improve code quality[1]. 

## Pipenv 

Pipenv is a package management tool for Python that combines pip and virtualenv. It can be used to manage dependencies and create isolated Python environments for LangChain projects[1]. 

## dspy 

dspy is a Python library for working with Datasette, a tool for publishing and exploring data. It can be used with LangChain to incorporate data from Datasette into your applications[1]. 

## Helm 

Helm is a package manager for Kubernetes that simplifies the deployment and management of applications on a Kubernetes cluster. It can be used to package and deploy LangChain applications on Kubernetes[1]. 

## Kubernetes (k8s) 

Kubernetes is an open-source container orchestration platform used for automating deployment, scaling, and management of containerized applications. LangChain applications can be containerized and deployed on Kubernetes for scalability and high availability[1]. 

## Flux 

Flux is a tool for managing Kubernetes clusters using Git repositories as the source of truth. It can be used to manage the deployment and configuration of LangChain applications on Kubernetes[1]. 

## Neo4j 

Neo4j is a graph database management system used for storing and querying graph-structured data. It can be used with LangChain to incorporate graph data into your applications[1]. 

## Playwright 

 Playwright is a Python library for automating web browsers. It can be used with LangChain to interact with web-based data sources and APIs as part of your application workflows



# IAGen_ii



## Git merg _request 

1> switch/create branch

```git 
git switch -c  branch name 
```

2> add branch

```git
git add file name
```

3> commit the changes

```git
git commit -m "give access to users"

#in location path forward slac
```

4> push changes in main origin

```git 
git push origin new-feature

```

5> request to main to merge and assign reviewer




6>  if only you update main dir with latest code
```git 
git pull origin main

```


## adding user and email for connect git

```git

git config user.name "ur Name"
git config user.email "Your email"

```


# Langchain + chainlit + pdf 


1. load the env
2. use text splitter & system templet
3. upload the pdf
4. read the pdf - split the text into chunks 
5. create metadata for each chunks
6. Croma vector DB
7. create chain that Croma Db
8. save metadata & text in session


> python -m venv venv

> venv\Scripts\activate

> pip install python dotenv


