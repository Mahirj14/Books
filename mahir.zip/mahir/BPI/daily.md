Synatx:  
# Command to create <name of Venv>  
python -m venv <name of Venv>

# Command to activate the venv  
<name of Venv>\scripts\activate

Egs:  
python -m venv diab_llm_env  # Command to create venv  
diab_llm_env\scripts\activate # Command to activate the venv

python -m venv .venv  
.venv\scripts\activate

python -m venv churn_llm_env   
churn_llm_env\scripts\activate



------------------------------------


Nepolean usecase

---> using neo4j graph db we have to retriew the output usning llm models


![[nepolean_usecase.png]]

HTML > DATA CLEANING > json > chunking > embedding > create node relationship > vector RAG & GraphRAG > Retrival





IAGen_ii



#GIT_merg _request 

1> switch/create branch

```git switch -c new-feature
```



