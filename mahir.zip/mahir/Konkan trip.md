
> Bengaluru - mengaluru - Udupi - Gokrna - Goa- Mumbai 

- so the jorney start from benglrur ksrtc relawaiy station at night , in train in met two ppl who going to amrutham temple near dharmshtal which is very famous in dakshin kannada side 
- so in mengluru pavan is hosting me at his house but Omg he home is so far i drop of Manglore junction and from there i took bus for lalbag(ksrtc) n from their i got bus number 33 which drop me akash bhavan last stop 

- so i came to pick me up  and his home is very tiny like 1RK one kitchen and room for sleeping he is stayiing with his wife n daughter
- but i like that RK which i imagine very suitable for me. basically he is working in pharma, he just have to go some location and just sigh in from there very easly work but i feel something glitchy as he said he lost lot of money in hospital and lost money somwhere other
but he seems friendly and ask for help if needed. 

- but he is very addicted to ciggarete 1-2 boxin days whic is very much. but after reached out there i had freshen up and he decide he explored me city. but as we started very heavy raining i dint expect that thing, n believe me its very heavily raining in manglore not ieven stopping soi took umbrella and he has raincoat i tried first neer dose OMG i like bcz of sweetness then we went mangaladevi temple  then he dropped me sultan buthery from their i took boat it frop beach side as i hungry so itried fish fried and toddy such a nice experinece then explroe the beach n do vlogging while return kudle temple and pabbas ice creame OMG i love this place like tupti ice creame in gandhinagar  then at eve he come to drop me but for dinner he said lets go for PUB in big bollywod its nice bar i have coldrirks and he has wishky i guess n i had chicken the songs r good in backgroud so i danced 

- next day i decuded to go udupi take bus from kottara cowk n then usdpi i had krishna mandir temple but the thing is without shirt u have to enter the is diffrent level thing, and then i off to manipal heritage village which i like diffrent wooden home from diffrent years then headed to malpe beach which typical beach their i hv lunch rice+fishfry then explroed beach and off to kapu beach had a lot walk finally reach the spot and i lik elight house view OMG its so good. then i call it day off with having kichhadi in dinner in BAR

- next day i have to catch early morning train og 5:45 but what a fucking mess we left home ealry but he dont know the route of junction and somhow my map is not woeking n fuck i missed my train then i decide go with bus which is longer jorney but i see coastal line view while going. finally reach gokarna and decise to stay is MG cottage which is nice place but gokrna is very small town with two man temple and beches main, kidle, om, half moon i vidted two off them but somehow  all are same then good thing is the bakery cake after lunch anf dinner
- gokrna to goa which id in train quite good experince to mudgaon


-  mudgoan - panjim -mapusa - anjuna then had long walk for musafir hotel on top of heavy raining my GOD i only remeber that thing


>GOA


-anjuna beach which is in north goa tpical beach which young ppl come for chilling
-next day panjim i went old goa i loved it the colorful house the conerto 31 cafe orange cake , mr baker 1922 prons and beef petties best thing is goan fish fry  thali and buy some famous zanteys kaju

- talk with delhis builder amazing he having 15 days jorney 
- what happen in my hostel one drunk guy came in midnight and he is very drunk n fall from floor n then who shoothout she he went
- today i took train for mumbai from thivim bus depot - the hunt of food in north goa is different you wont find easli cheap food very expensive everyhting
- bought somw suvenoirs from calangoate which very havy rush beach for all ppl who come goa visit here come first mostly family people. buy book from mapusa circle book FAIR

>MUMBAI

-- goa to mumbai travel jorney in konkan kanya express , the konkan railway whole department is diffrent and they very good in managment

-- Thane -- Airoli -- thane -- dadar - CSMT- churchgate

reached at umesh places very small room they ppl liviing in i had some relax and went first office for yaman meeting there i show airoli capgemini campus very huge  meet to yaman and had chai poha.

then got mumbai local from diga goan -- its very hective evry time i have get train  from ticket michine -- if you really want to understand mumbai people stand 10 min at dadar satation .

first i visit sidivinayak temple very huge line but somehow got darshan and took prasad , very hot templreture . in lunch had paubhaji -- dadar flowermarket is very rushy had lassi their

then hadead to CSMT Terminus very big n rushy , had vadapua opposite the site. explroe that area and parsi cafe had pudding --visit taj hotel -- gateway of india -- click lot of photos and headed to marine drive which i live to witness sunset and had rustom sandwish icecreame. then i got csmt-thsne very long triain very tired i am n then decide to next day pune headed.

