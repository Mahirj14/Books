
> How to check UDFs

    SHOW USER FUNCTIONS;

> can we create snowpipe on internal stage ?

    YES

> How to call SP

     CALL PROCEDER_NAME()

> How to store semi structred data

     Variant

> Snowflake table types

     permanent, transient, temoorary, external

> How to find snowflake version

     select current_version();

> Snowflake edititon

     starnard, enterprise, business critical, virtual private snowflake

> TASK Syntax

     CREATE TASK TASK1
     WAREHOUSE = COMPUTE_WH
     SCHEDULUE = '5 MINUTE'
     AS
     SQL Statment or
     CALL Proceder()

> Load only valid records dusring copy statment

     on_error = continue

> View to check storage of a tabale

     Table_Storage_Metrics

> Does sequre materilized view occupy storage

     YES

> can we perfom DML on Materialized view ?

     NO

> can Materialized view can be crreated ono multiple table?

    NO

> How to omplement CDC?

     Streams

> Retention time of snoflake table

     1 day

> How to check does stream has data or not?

     System$Strem_Has_date('Strem_N')

> How to check time travel

     QueryID
     offset
     Timestamp

> GET/PUT Command work ON UI?

     NO

> time travel

	CREATE TABLE mytable(col1 NUMBER, col2 DATE)  DATA_RETENTION_TIME_IN_DAYS=90;
	
	ALTER TABLE mytable SET DATA_RETENTION_TIME_IN_DAYS=30;