

- Create warehouse using UI
- make WH using sql query
- delete/resume WH


## scaling policy
- ECONOMY
- STANDARD
## pricing

- depends on compute and storage
             - Active warhouse hourly charged
             - charged by seconds

## Loading DATA

- BULK LOADING
- Continues loading

```sql
COPY INTO Table
from @stages
file formate =( type = csv feild_delimeter= ',' slip_header = 1)
files = ('test.csv')
```

# Stages
   - internal 
   - extrnal
   
List @stage_name

pattern = startwith_name


ON_ERROR = Continue (if data type is INT but it allows string)
ON_ERROR = ABORT STATMENT (default)
ON_ERROR = SKIP_FILE  (skil first file which hs error scan 2nd file)
ON_ERROR = SKIP_FILE_3( three error handling)


DESC File format table


## Validation_error

RETURN_10_ROWS
RETURN_ERRORS'

TRUNCATECOLUMN = TRUE
FORCE = TRUE (previously file loeaded but after this condition then also needed)

select * from snowflae.account_usage.load_history


## Loading unstructerd Data

RAW FILE: id :: int
RAW_FILE : name : str


RAW_FILE: job.salary :: int
RAW_FILE : job.tittle :: str

RAW_FILE : Spoken_language[0]

```sql

select
RAW_FILE : name : : str,
f.values : language :: str as first_language
f.values : level  :: str as level
table(flatten (RAW_FILE = Spoken_languages)) f


select RAW_GILE : NAME :: STR
```



### Dedicated warhouse


USER-ROLE-WAREHOUSE

Create user ds1 PASSWORD, LOGIN_NAME , ROLE,


ALTER WAREHOUSE NAME
SET WAREHOUSE_SIZE = 'small'


SCALING UP - increase size
SCALING OUT -expand horizontal

CACHING automatically manged

CLUSTER KEY: subset of wors locate in ,micro portiom

clustering for big table -use column which frequently use in WHERE/JOINS

### Establishes conne to AWS

```sql

create or replace storage integration s3_int
  TYPE = EXTERNAL_STAGE
  STORAGE_PROVIDER = S3
  ENABLED = TRUE 
  STORAGE_AWS_ROLE_ARN = ''
  STORAGE_ALLOWED_LOCATIONS = ('s3://<your-bucket-name>/<your-path>/', 's3://<your-bucket-name>/<your-path>/')
   COMMENT = 'This an optional comment' ;
   
```



CREATE PIPE AWSPIPE
AUTO INGEST =TRUE
AS COPY INTO
FROM @STAGE

FEILD_OPTINALLY_ENCLOSED_BY

SELECT SYSTEM$PIPESTATUE("NAME")  (for pipe status)

snowflake.account_usssage.copy_history


> VIEWS

 - NORMAL
- MATERLIZED(created on single table not multiple)
 - SECURE

> CDC

create streams

> how to loed semistrudctyred data?

varient


> Partitioning

- FAST/EASY ACCESS
- PARALLELISM / RESOURCE UTILIZATION

HOW TO CHOOESE WHICH COLUMN FOR PARTITIONING
- high cardinality / low cardinality
- if you doing more filtering on one column thenyiu use for partitioninig


### **How Micro-Partitions Work**

1. **Automatic Data Partitioning**: When data is loaded into a table, Snowflake automatically divides it into micro-partitions based on:
    
    - Order of data ingestion.
    - Internal optimization algorithms.
    - No manual partitioning is required (unlike traditional databases).
2. **Metadata Storage**: For each micro-partition, Snowflake stores metadata such as:
    
    - **Min/Max values** for each column.
    - **Null value counts**.
    - Information about the distribution of data.
    - These metadata details are used to optimize query performance by enabling Snowflake to skip irrelevant partitions.
3. **Clustering and Sorting**:
    
    - Micro-partitions are automatically **clustered** and **sorted** based on the natural order of data ingestion.