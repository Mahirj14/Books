

> "CRTL + B"     ```open side explorer bar``` 

> "CRTL+ J"       ```open terminal```

> " CRTL +ALT + UP ARROW/DOWN"

> " CRTL + D "        ```  Select same name```

> " CRTL + N "         ```new file open```

