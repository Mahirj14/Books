[[aws]]

> Migration project ( OracleDB To AWS )

![[Screenshot 2024-07-29 140637.png]]


![[Screenshot 2024-07-29 140707.png]]


3000 table
800 migrate as of now

- daily what size of incremental data coming ?
- how many glue jobs total running ?
- list down major dims/fact table name from redshift

![[Screenshot 2024-07-29 140354.png]]

![[Screenshot 2024-07-29 140328.png]]