
>connecting postgre

> dynamic frame parameters

> s3-redshift

> redshift to postgre- glue

