
## DAY1

1. Cumulative tables keep history clean,  
2. Temporal dimensions can explode your model,  
3. Run-length encoding saves the day when every byte counts.