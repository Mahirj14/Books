
Here are some commonly used Unix commands for day-to-day use in projects:

1. `ls`: Lists the contents of a directory.
2. `cd`: Changes the current working directory.
3. `mkdir`: Creates a new directory.
4. `rm`: Removes files or directories.
5. `cp`: Copies files or directories.
6. `mv`: Moves or renames files or directories.
7. `grep`: Searches for patterns in files.
8. `find`: Searches for files in a directory hierarchy.
9. `tar`: Creates or extracts archive files.
10. `gzip` or `gunzip`: Compresses or decompresses files.
11. `vim` or `nano`: Text editors for modifying files.
12. `cat`: Displays the contents of a file.
13. `less` or `more`: Displays the contents of a file page by page.
14. `chmod`: Changes file permissions.
15. `chown`: Changes the owner of a file or directory.
16. `ps`: Lists running processes.
17. `kill`: Terminates a running process.
18. `ssh`: Secure Shell for remote login.
19. `scp`: Secure Copy for copying files between hosts.
20. `sudo`: Runs a command with superuser (root) privileges.
21. `apt-get` or `yum`: Package managers for installing software on Linux distributions.
22. `git`: Distributed version control system.
23. `curl` or `wget`: Command-line tools for transferring data using various protocols.
24. `ping`: Tests network connectivity to a host.
25. `top` or `htop`: Displays system resource usage and running processes.
26. `df`: Reports file system disk space usage.
27. `du`: Estimates file space usage.
28. `ln`: Creates hard or symbolic links to files.
29. `man`: Displays the manual page of a command.
30. `echo`: Prints a line of text to the standard output.


Sure, here are some examples of how these Unix commands are used:

1. `ls`
   - `ls` - Lists files and directories in the current directory.
   - `ls -l` - Lists files and directories with detailed information (permissions, owner, size, etc.).
   - `ls *.txt` - Lists only files with a `.txt` extension.

2. `cd`
   - `cd /path/to/directory` - Changes the current directory to `/path/to/directory`.
   - `cd ~` - Changes the current directory to the user's home directory.
   - `cd ..` - Changes the current directory to the parent directory.

3. `mkdir`
   - `mkdir new_directory` - Creates a new directory named `new_directory`.
   - `mkdir -p /path/to/nested/directories` - Creates nested directories if they don't exist.

4. `rm`
   - `rm file.txt` - Removes the file `file.txt`.
   - `rm -r directory` - Removes the directory and its contents recursively.
   - `rm -f *.log` - Forces the removal of all files with a `.log` extension without prompting.

5. `cp`
   - `cp file.txt /path/to/directory` - Copies `file.txt` to the specified directory.
   - `cp -r source_directory /path/to/destination` - Copies the `source_directory` and its contents to the specified destination path.

6. `mv`
   - `mv file.txt /path/to/directory` - Moves `file.txt` to the specified directory.
   - `mv old_name.txt new_name.txt` - Renames `old_name.txt` to `new_name.txt`.

7. `grep`
   - `grep 'pattern' file.txt` - Searches for the specified pattern in `file.txt`.
   - `grep -r 'pattern' /path/to/directory` - Recursively searches for the pattern in all files within the specified directory.

8. `find`
   - `find /path/to/directory -name '*.py'` - Finds all files with a `.py` extension in the specified directory and its subdirectories.
   - `find . -type d -empty` - Finds all empty directories in the current directory and its subdirectories.

9. `tar`
   - `tar -czf archive.tar.gz /path/to/directory` - Creates a compressed archive `archive.tar.gz` from the specified directory.
   - `tar -xzf archive.tar.gz` - Extracts the contents of the compressed archive `archive.tar.gz`.

10. `gzip` and `gunzip`
    - `gzip file.txt` - Compresses `file.txt` and creates `file.txt.gz`.
    - `gunzip file.txt.gz` - Decompresses `file.txt.gz` and creates `file.txt`.

Sure, here are some more examples of commonly used Unix commands:

11. `vim` (text editor)
    - `vim file.txt` - Opens `file.txt` in the Vim text editor.
    - `:wq` - Saves changes and quits Vim.
    - `/pattern` - Searches for a pattern in the file.

12. `cat`
    - `cat file.txt` - Displays the contents of `file.txt`.
    - `cat file1.txt file2.txt > combined.txt` - Concatenates the contents of `file1.txt` and `file2.txt` and writes the output to `combined.txt`.

13. `chmod`
    - `chmod 644 file.txt` - Sets the permissions of `file.txt` to read and write for the owner, and read-only for the group and others.
    - `chmod +x script.sh` - Adds execute permission to `script.sh`.

14. `chown`
    - `chown user:group file.txt` - Changes the owner and group of `file.txt` to the specified user and group.

15. `ps`
    - `ps` - Lists all running processes associated with the current user.
    - `ps aux` - Lists all running processes on the system.

16. `kill`
    - `kill 1234` - Terminates the process with PID 1234.
    - `kill -9 1234` - Forcibly terminates the process with PID 1234.

17. `ssh`
    - `ssh user@remote_host` - Connects to the remote host as the specified user.
    - `ssh -i key_file.pem user@remote_host` - Connects to the remote host using the specified SSH key file.

18. `scp`
    - `scp file.txt user@remote_host:/path/to/directory` - Copies `file.txt` to the specified directory on the remote host.
    - `scp -r local_directory user@remote_host:/path/to/directory` - Copies the entire `local_directory` to the specified directory on the remote host.

19. `sudo`
    - `sudo command` - Runs the specified command with superuser (root) privileges.
    - `sudo -u user command` - Runs the specified command as the specified user.

20. `apt-get` (package manager for Debian-based Linux distributions)
    - `apt-get update` - Updates the package lists from the repositories.
    - `apt-get install package_name` - Installs the specified package.
    - `apt-get remove package_name` - Removes the specified package.

Sure, here are 10 more commonly used Unix commands with examples:

1. `echo`
   - `echo "Hello, World!"` - Prints "Hello, World!" to the console.
   - `echo $PATH` - Prints the value of the `PATH` environment variable.

2. `sed` (stream editor)
   - `sed 's/pattern/replacement/g' file.txt` - Replaces all occurrences of "pattern" with "replacement" in `file.txt`.
   - `sed -i 's/pattern/replacement/g' file.txt` - Replaces all occurrences of "pattern" with "replacement" in `file.txt` and saves the changes to the same file.

3. `awk` (data processing language)
   - `awk '/pattern/ {print}' file.txt` - Prints lines that match the specified pattern in `file.txt`.
   - `awk '{print $1}' file.txt` - Prints the first field (column) of each line in `file.txt`.

4. `sort`
   - `sort file.txt` - Sorts the lines in `file.txt` in alphabetical order.
   - `sort -n file.txt` - Sorts the lines in `file.txt` in numerical order.

5. `uniq`
   - `sort file.txt | uniq` - Removes duplicate consecutive lines from `file.txt` after sorting it.
   - `uniq -c file.txt` - Counts the occurrences of each line in `file.txt`.

6. `cut`
   - `cut -d ',' -f 1,3 file.csv` - Extracts the 1st and 3rd fields (columns) from a comma-separated file (`file.csv`).

7. `diff`
   - `diff file1.txt file2.txt` - Compares the contents of `file1.txt` and `file2.txt` and shows the differences.

8. `head` and `tail`
   - `head -n 10 file.txt` - Displays the first 10 lines of `file.txt`.
   - `tail -n 20 file.log` - Displays the last 20 lines of `file.log`.

9. `xargs`
   - `find . -name '*.py' -print0 | xargs -0 grep 'pattern'` - Finds all Python files in the current directory and subdirectories, and searches for the specified pattern in them using `grep`.

10. `cron`
    - `crontab -e` - Opens the crontab editor to schedule recurring tasks.
    - `0 0 * * * /path/to/script.sh` - Runs the `script.sh` script at 00:00 (midnight) every day.

