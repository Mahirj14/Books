[[sql]]


> create table custmer( 

	order_id varchar(40) not null,
	name varchar()
	number integer(),
	address varchar()
			

)

> insert into table values( )


- alter table customer update/drop/set

- **constraint** not null  -- that means no null value can be enter
					- check function = give any condition like (amount > 0)
					- default
- only one primary key one table, there hsould no NULL in primay key column
- in unique column only one NULL


## DAY3

-  sorting and where  condition
- between  and
  - like  _%   
- order by desc


# Day4
- group by
- having

# Day5
- joins

# Day6
- string_agg
- date

## Day7

- set
- round = 
- seiling = next integer
- floor = 0.5> next else same one
- union
- uniaol all
- intersect

VIEWS vs MATERILISED VIEW
 - in normal views every time run sql query and fetched new record
 - in Materilised view first run sql query store data and every time fetch that data(in scenario when you know data will change after week) its very fast.
 - you can refresh in interval
## temp table
- temporvery table
 - it similer to materlized view but its only for one session



|Feature|Snowflake|Redshift|
|---|---|---|

|   |   |   |
|---|---|---|
|**Cloud Support**|Multi-cloud (AWS, Azure, GCP)|AWS only|

| **Storage-Compute Separation** | Complete separation | Partial separation with RA3 nodes |
| ------------------------------ | ------------------- | --------------------------------- |
|                                |                     |                                   |

|   |   |   |
|---|---|---|
|**Data Sharing**|Native, real-time, zero-copy|Not natively supported|

|   |   |   |
|---|---|---|
|**Query Semi-Structured Data**|Native support via `VARIANT` data type|Requires transformation|

|   |   |   |
|---|---|---|
|**Data Compression**|Fully automated|Requires manual optimization|

|   |   |   |
|---|---|---|
|**Concurrency Scaling**|Virtual Warehouses for isolation|Temporary capacity with concurrency scaling|

|   |   |   |
|---|---|---|
|**Integration**|Generic integration with multiple platforms|Deep integration with AWS services|

|                        |           |           |
| ---------------------- | --------- | --------- |
| **Materialized Views** | Supported | Supported |

|   |   |   |
|---|---|---|
|**Performance Tuning**|Automatic|Requires manual tuning (keys, nodes)|