
[[sql]]

>REGEX


select user_id,name,mail  
from users  
where  
regexp_like (mail,'^[a-z]+[0-9a-zA-Z_.-]*@leetcode[.]{1}com$')

> col1 | col2
> 1 | a,b,c
> 2 | a,b 

select len( replace(col2, ' ,' , ' ')) as cnt from tabl

 col1 | col2 | cnt
> 1 | a,b,c | 3
> 2 | a,b  | 2


> mean/median/mode

mean:  avg()

mode : count() repeate more time

median : row_window function  (asc, desc)  if (0,1,-1) come then its median


1,-1 case take avg() also

> login/louout entry of employee sql

- make with clouase of in/out with  rank window function
- do left joining
- then sum group by


>rising temperature


SELECT a.id

FROM Weather a,Weather b

WHERE datediff(a.recordDate, b.recordDate) = 1

AND a.temperature > b.temperature;

> how to find correct email domain

SELECT email,
	CASE WHEN
	email LIKE '%_@_%_.__%' 
	THEN  'Valid'
	 ELSE  'Invalid'
	  END AS e_status 
FROM users;

> find order placed in current year

```sql
select orderid,orderdate
from employee
where YEAR(orderdate) =YEAR(getdate())

```

>employee with rank in all deparmnet

```sql

select ename,departname,salary
rank()over(partition by departmen orderby salary desc) as rank
from wmployee
```

> find all product which havent sold

```sql

select p. producname
from product p
left join sales s on p.productid = s.producid
where s.productid is null

```

> handling null value and replace that with avg salary

```sql

select empname, coleasc(salary,(select avg(salary)) from employess)

```
>Runnnig total

```sql
 select date,amount,
 sum(Amount) over (order by dates) as running_total
 from sales
```

> Moving Average

```sql

select date,
users,
AVG(users) over(orderby date 
			   ROWS Between 2 proceeding and current row)as MA
FROM table

```



> 2nd highest and lowest salary

```sql
with cte as(
select salary,date,
dense_rank() over(partiton by department order by date desc,
dense_rank() over(partiton by department order by date asc) as rn
from employee
)

select salary,name
from cte
where rn =2
```

> customer purchage previous and next value

```sql

select custid,purchasedate,aount,
LAG(Amount,1) over (partition by custid order by purchase date) as previous,
LEAD(Amount,1) over (partition by custid order by purchase date) as next
from purchase;

```