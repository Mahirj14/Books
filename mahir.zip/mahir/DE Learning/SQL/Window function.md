[[sql]]


```sql 

select c.name, .salary
max(salary) over(partision by department) as rn
from customet c


```
```sql
select e.*
max(salary) over(partison by dept_name) as max
from employee e
```


```sql
FRIST_VALUE
LAST_VALUE
```