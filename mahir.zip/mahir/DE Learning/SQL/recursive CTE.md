[[sql]]


I/P        O/P

| A   | A,B,C |
| --- | ----- |
| B   | A,C,B |
| C   | B,C,A |
|     | B,A,C |
|     | C,A,B |
|     | C,B,A |

SELECT TABLE