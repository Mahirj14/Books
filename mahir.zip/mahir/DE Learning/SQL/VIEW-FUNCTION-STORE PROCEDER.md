[[sql]]

### Views

A **view** is a virtual table based on the result set of an SQL query. It does not store the data physically but provides a way to simplify complex queries and enhance security by restricting access to specific data.

**Example:**

Suppose we have a table `Employees`:

| EmployeeID | FirstName | LastName | DepartmentID | Salary |
|------------|-----------|----------|--------------|--------|
| 1          | John      | Doe      | 101          | 60000  |
| 2          | Jane      | Smith    | 102          | 65000  |
| 3          | Mary      | Johnson  | 101          | 70000  |

We can create a view to see employees in department 101:

```sql
CREATE VIEW Department101Employees AS
SELECT EmployeeID, FirstName, LastName, Salary
FROM Employees
WHERE DepartmentID = 101;
```

Querying this view:

```sql
SELECT * FROM Department101Employees;
```

**Result:**

| EmployeeID | FirstName | LastName | Salary |
|------------|-----------|----------|--------|
| 1          | John      | Doe      | 60000  |
| 3          | Mary      | Johnson  | 70000  |

### Functions

A **function** in SQL is a reusable set of SQL statements that perform a specific task and return a single value. Functions can be scalar (returning a single value) or table-valued.

**Example:**

Let's create a scalar function to calculate the annual bonus for an employee based on their salary.

```sql
CREATE FUNCTION CalculateBonus (@Salary DECIMAL)
RETURNS DECIMAL
AS
BEGIN
    RETURN @Salary * 0.1;
END;
```

Using the function:

```sql
SELECT FirstName, LastName, dbo.CalculateBonus(Salary) AS Bonus
FROM Employees;
```

**Result:**

| FirstName | LastName | Bonus  |
|-----------|----------|--------|
| John      | Doe      | 6000.0 |
| Jane      | Smith    | 6500.0 |
| Mary      | Johnson  | 7000.0 |

### Stored Procedures

A **stored procedure** is a group of SQL statements that can be executed as a single unit. Stored procedures can accept parameters, perform operations, and return results.

**Example:**

Let's create a stored procedure to get employees by department:

```sql
CREATE PROCEDURE GetEmployeesByDepartment @DepartmentID INT
AS
BEGIN
    SELECT EmployeeID, FirstName, LastName, Salary
    FROM Employees
    WHERE DepartmentID = @DepartmentID;
END;
```

Executing the stored procedure:

```sql
EXEC GetEmployeesByDepartment @DepartmentID = 101;
```

**Result:**

| EmployeeID | FirstName | LastName | Salary |
|------------|-----------|----------|--------|
| 1          | John      | Doe      | 60000  |
| 3          | Mary      | Johnson  | 70000  |

### Exception Handling

SQL provides mechanisms to handle exceptions (errors) during the execution of SQL statements. The `TRY...CATCH` construct is commonly used for this purpose.

**Example:**

Let's create a stored procedure with exception handling to update an employee's salary and log any errors that occur:

```sql
CREATE PROCEDURE UpdateSalary @EmployeeID INT, @NewSalary DECIMAL
AS
BEGIN
    BEGIN TRY
        UPDATE Employees
        SET Salary = @NewSalary
        WHERE EmployeeID = @EmployeeID;

        PRINT 'Salary updated successfully.';
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        -- Log the error details
        INSERT INTO ErrorLog (ErrorMessage, ErrorSeverity, ErrorState, ErrorDate)
        VALUES (@ErrorMessage, @ErrorSeverity, @ErrorState, GETDATE());

        -- Re-raise the error
        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH;
END;
```

In this example, if an error occurs during the salary update, the error details are logged into an `ErrorLog` table, and the error is re-raised.

These examples cover the basics of views, functions, stored procedures, and exception handling in SQL. Each concept helps in managing and manipulating data more effectively within a database.