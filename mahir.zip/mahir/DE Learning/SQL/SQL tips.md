[[sql]]

**sql-tips**


1. You should always use subqueries over CTEs when you can.
 CTEs take up too much space, so you might as well save space by nesting the subqueries and further
 integrating them into the query. More nests = better query.

2. Make sure you always put your best foot forward with analyses.
 Don't take the easy route and be lazy by just making a simple bar 
chart or line graph. You should always try to do more complex things and implement ML when possible.

3. It's always a good idea to use sequential aliases in your queries so the reader can more easily follow.
 I recommend a, b, c, d, e, f, g, h, and so on. It's makes your code cleaner and easier to read. 

4. I recommend using SELECT * when you can so you can get all of the columns just in case. 
You never want to limit the number of columns you pull because you might miss 
out on important data. More columns = More Good Data.

5. Don't waste time on silly processes like code reviews and testing code in staging 
if you're just making a small change and you feel confident that you have it right.
 Push that sucker straight to prod with confidence baby!!!



--  Here are some key points for SQL optimization:  
  
  
> Use Indexing: Properly indexing your database tables can significantly speed up query performance by allowing the database to quickly locate the rows needed for a query.  
  
>Optimize Joins: Minimize the number of joins and use appropriate join types (e.g., INNER JOIN, LEFT JOIN) to ensure efficient data retrieval.  
  
> Avoid SELECT * : Instead of selecting all columns using SELECT *, explicitly specify only the columns needed for the query to reduce unnecessary data transfer and processing overhead.  
  
>Use WHERE Clause Wisely: Filter rows early in the query using WHERE clause to reduce the dataset size before joining or aggregating data.  
  
>Avoid Subqueries: Whenever possible, rewrite subqueries as JOINs or use Common Table Expressions (CTEs) for better performance.  
  
>Limit the Use of DISTINCT: Minimize the use of DISTINCT as it requires sorting and duplicate removal, which can be resource-intensive for large datasets.  
  
>Optimize GROUP BY and ORDER BY: Use GROUP BY and ORDER BY clauses judiciously, and ensure that they are using indexed columns whenever possible to avoid unnecessary sorting.  
  
>Consider Partitioning: Partition large tables to distribute data across multiple nodes, which can improve query performance by reducing I/O operations.  
  
>Monitor Query Performance: Regularly monitor query performance using tools like query execution plans, database profiler, and performance monitoring tools to identify and address bottlenecks.


>   #good #rules


1- Filter Early, Aggregate Late: Apply filtering conditions in the WHERE clause early in the query, and perform aggregations in the HAVING or SELECT clauses as needed.  
  
2- Use table aliases with columns when you are joining multiple tables.  
  
3- Never use select *, always mention list of columns in select clause before deploying the code.  
  
4- Add useful comments wherever you write complex logic. Avoid too many comments.  
  
5- Use joins instead of correlated subqueries when possible for better performance.  
  
6- Create CTEs instead of multiple sub queries , it will make your query easy to read.  
  
7- Join tables using JOIN keywords instead of writing join condition in where clause for better readability.  
  
8- Never use order by in sub queries , It will unnecessary increase runtime. In fact some databases don't even allow you to do that.  
  
9- If you know there are no duplicates in 2 tables, use UNION ALL instead of UNION for better performance.

>**UNION: only keeps unique records**. **UNION ALL: keeps all records, including duplicates**. and both side colmn soul be same

> Syntax: NVL takes two arguments, while COALESCE takes two or more arguments.

where: only aplly in indivisual row

select name from emp where salary> 1000
having by : apply on agg raw

select name from emp where avg(salary)> 1000


CHAR: store fix number of character
VARCHAR: store variable number of character

> **What is the difference between a function and a procedure?**

- **Function** should always return a value whereas for a **procedure** it’s not mandatory to return a value.
    
- Function can be called from a SELECT query whereas procedure cannot be called from a SELECT query.
    
- Function is generally used to perform some calculation and return a result. Whereas procedure is generally used to implement some business logic.


>PRAGMA

To understand this further, let’s imagine we have two procedures, pr_main and pr_log. PR_MAIN is a normal procedure whereas PR_LOG is declared as PRAGMA AUTONOMOUS TRANSACTION.

In the execution block of PR_MAIN, let’s imagine we do some DML operations like INSERT 100 records into a test table and then within the exception handling block of PR_MAIN we call the PR_LOG procedure. PR_LOG procedure will do some inserts into the log table and then do some commits.

Now when we call the PR_MAIN procedure, if there was an unexpected exception then the PR_LOG procedure will get called. However, any commit done in the PR_LOG procedure will not impact the open transactions in PR_MAIN procedure because PR_LOG is declared as autonomous transaction so the commits and rollback within a autonomous transaction procedure only impacts its own transaction.

It’s like autonomous transaction procedure will have its own database session so any transactions commit or rollback only impacts its internal database session.


> VIEW/ SNONYM/ MATEREALIZED VIEW

- **View** is a database object which is created based on a SQL Query. It’s like giving a name to the results returned from a SQL Query and storing it in the database as a view.

If the query result changes then the data in view also changes. View is directly linked to the SQL Query over which it was created.


- **materialized views** are also database objects which are formed based on a SQL Query however unlike views, the contents or data of the materialized views are periodically refreshed based on its configuration.

The contents of view will get updated automatically when the underlying table (forming the query) data gets changed. However, materialised views can be configured to refresh its contents periodically or can be manually refreshed when needed.

Creating materialized views can be a very good approach for performance tuning especially when dealing with remote tables.

- **Synonym** on the other hand is just an alias or an alternate name that you can provide to any database objects such as tables, views, sequences, procedures etc.

Synonym is created for a single database object whereas view can be created on a query where the query may have been formed by multiple tables.