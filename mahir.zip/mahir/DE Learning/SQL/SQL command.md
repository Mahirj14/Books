#sql #joins
[[sql]]

>when sql executed which sequence command executed?

 *FROM > WHERE > GROUPBY > HAVING > SELECT > ORDERBY > LIMIT

```sql 

customer
employee

select c.name, c.salary,e.height,e.city
from customer c 
inner join emplyoee e 
on id.c = id.e
 
```


select id, name, EXTRACT(day from DOB) as birthday from employee

                    here EXTRACT command taking day from DOB


select id , name, DATE_ADD(dob, INTERVAL 1 MONTH ) as updated_date
                           using Data_add


------------------------------------------------------------

| Table1 |
| ------ |
| 1      |
| 1      |
| 2      |
| Null   |
| Null   |
 
| Table 2 |
| ------- |
| 1       |
| 3       |
| Null    |

> inner join : joining only marching cases (1,1), (1,1)

> left join : inner + unmatch cases =  (1,1), (1,1),(2, ), (null, ), (null, )

> right join : inner + unmatch =  (1,1), (1,1), (3, ), (null, )

> full join :  (1,1), (1,1),(2, ), (null, ), (null, ) (3, ), (null, )

> cross join : 5*3 = 15 output



-------------

| RANK | COUNTRY  |
| ---- | -------- |
| 1    | norway   |
| 2    | finland  |
| 3    | denmark  |
| 4    | iceland  |
| 5    | isreal   |
| 128  | india    |
| 129  | srilanka |
|      |          |
we need to display a few specific Rows(india, srlanka ) always at top of the query result.

```sql

select *,  case when country = " india" then rank 1
			when country = " srilanka" then rank 2
			else 3 End as derived rank
from happiness_tbl

```
> ROLLUP:  
  
ROLLUP generates subtotals for a specified set of columns in the result set, producing summary rows that represent higher-level aggregations.  
It computes subtotals from left to right based on the order of columns specified in the ROLLUP clause.  
  
Example:  
SELECT region, city, SUM(sales) AS total_sales  
FROM sales_table  
GROUP BY ROLLUP(region, city);  
  
This query would generate subtotals for both region and city, as well as a grand total for all regions and cities combined.  
  
> CUBE:  

CUBE generates all possible combinations of groupings for the specified columns, providing a comprehensive set of subtotal and grand total rows.  
It's more expansive than ROLLUP, as it includes all combinations of the specified columns.  
  
Example:  
SELECT region, city, product, SUM(sales) AS total_sales  
FROM sales_table  
GROUP BY CUBE(region, city, product);  
  
This query would generate subtotals for region, city, and product, as well as combinations of these columns, and a grand total for all combinations.  
  
In essence, ROLLUP creates subtotals based on a hierarchical order of columns, while CUBE generates all possible combinations of subtotals for the specified columns.  
  
We have grouping sets as well as third option. See all of them in action from the link in the comments section.  


```sql

#update set to swap the gender

UPDATE tableA 
   SET Gender = CASE  
                WHEN Gender = 'Male' THEN 'Female'  
                ELSE 'Male'  
                END
```

```sql

SELECT EMPNAME,DEPT,CONTACTNO,CITY, 
COUNT(*) FROM DETAILS                    #find duplicate
GROUP BY EMPNAME,DEPT,CONTACTNO,CITY
.
.
.
DELETE FROM DETAILS
WHERE SN NOT IN (                       #using not in find records n delete
    SELECT MIN(SN)
    FROM DETAILS
    GROUP BY EMPNAME, DEPT, CONTACTNO, CITY
);


##window##

 with cte as (select e.*
 row number()over( partiision by name. orfderby name) as rn
 from employee
 )

delete from cte 
where rn > 1


```

```python
#copy data from one table to another table

select *
into table1
from table2
where 1 = 1

#where 1=1 meaning its always true, return all record without filtering,make complex query more easier, u can easily start with AND
```

> left anti joins:

its do ooposite of inner join( unmatching records)


>
>columnar base : parqet, read high, compression good

id
id
id
row base : csv, write high, poor
id,name,salary | id,name,salary

use record 3*3 in table (id,name,salary)

> why spark is lazy is why good things is

if u hv dataset where u want 10lav> sal then if spark is not lazy then count all record
but if lazy then apply filter first

> partition skew = 

> how to get latest/older record from table

select *
from table
orderby date desc  
limit 1

select *
from table
orderby date asc  
limit 1

> 2nd highest salary

SELECT MAX(Salary)
FROM Employee
WHERE Salary < (SELECT MAX(Salary) FROM Employee);

SELECT DISTINCT Salary
FROM Employee
ORDER BY Salary DESC
LIMIT 1 OFFSET 1;

offset 1 mean skip 1 row

```python

string_agg()

# for combining records of same group

```


```python

#creat function readyly use 

CREATE FUNCTION CalculateBonus (@Salary DECIMAL)
RETURNS DECIMAL
AS
BEGIN
    RETURN @Salary * 0.1;
END;


#create proceder

CREATE PROCEDURE GetEmployeesByDepartment @DepartmentID INT
AS
BEGIN
    SELECT EmployeeID, FirstName, LastName, Salary
    FROM Employees
    WHERE DepartmentID = @DepartmentID;
END;

```


```sql

with cte as(
select *,
row_nnumber() over(partition by company order by salary desc) as mx_rn,
row_nnumber() over(partition by company order by salary asc) as mi_rn
)

select company, salary
case when mx_rn =1  then city end as maxi
case when mn_rn =1  then city end as mini

from cte
where mx_rn =1 or mn_rn =1
order by company,salary

----------------------------


with cte as (select e1.* count(e2,magaerid) over (partition by e2.managerid)cnt
from employee e1
inner join employee e2
on e1.id=e2.managerid)
```