
-  .append
- .insert
- .remove
- .pop
-  math.sqrt
- math.log
- math.pi
- round( , )
- First two items states[:2]
- Last two items states[-2:]
- Range of items states[2:4]
- shorted( )
-  vowels = ['a', 'i', 'e', 'u', 'o']
	sorted(vowels, reverse=True)
	['u', 'o', 'i', 'e', 'a']
- .reverse


- high_nums = list(range(95, 100))
	igh_nums
	[95, 96, 97, 98, 99]
	Use a third argument to specify a distance to skip between

- numbers in a list:
	 odds = list(range(1, 10, 2))
	 odds
		[1, 3, 5, 7, 9]

- The methods keys(), values(), and items() return different
aspects of a  **dictionary**
