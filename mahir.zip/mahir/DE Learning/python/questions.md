[[PYTHON]] #questions

```python

# how to make square numbers in certain range

limit = int(input("define limit:"))

limit = int(limit ** .5)

for i in range (1,limit +1):
    
    print(i*i)
```

```python

#how to find factorial of given number

def fact(n):

for n < 1:
   return 1
else:
   return n*fact(n-1)

# 5 * fact(n)
# 5 * 4 * fact(n)
# 5 * 4 * 3 * fact(n)
# 5 * 4 * 3 * 2 * fact(n)
# 5 * 4 * 3 * 2* 1 * fact(n)
```



```python

#find out numbr of items in list using recursion

l = [1,2,3,4]

def count():
 if not l:
   return 0
 return 1 + count(l[1:])
 

#count 4
 
```


```python

#repeat each caracter N times

s = "mahi"

 #for loop
 s1 = ""
      
 for i in s:
     s1 = s1+ i*3
    
 print(s1) 


#recursion

def multiple_string(s,n):
    if len(s)== 0:
        return "" 
    return s[0]*n + multiple_string(s[1:],n)
    
print(multiple_string(s,3))
```

```python

# reverse the order of string

sentence = "this is namma bengluru"

def words_reverse(sentence):
    list_words = []
    senetence_list =sentence.split('')
    while(len(sentence_list))>0:
        word =sentence_list.pop()
        list_words.append(word)

return ' ' .join(list_words)

print(words_reverse(sentence))


#alternative

def my_function(x):  
  return x[::-1]  
  
mytxt = my_function("this is namma bengluru")  
  
print(mytxt)

```


```python
# k most frequent element in array

(1,2,3,1,1,3)
 
def k_most_time(input_array,k):
    base_dict = dict[]
    final_set = set()
    for i in input_array:
        
        if i in base_dict :
             base_dict =+ 1
            if (base_dict[i] >= k):
                final_set.add(1)
            
        else:
            base_dict = 1
            
    return final_set
            
return(k_most_time((1,2,3,1,1,3),2))
```


> instead of using IF/ELSE multiple time use Def function then u can create dictionary


```python

#count the Frequency of Elements in a List

input_list = [1,2,3,4,5,6,6,2,3]

def counter(input_list):
    freq ={}
    for i in input_list: 
        freq[i]=freq.get(i,0)+1
    return freq
print(counter([1,2,3,4,5,6,6,2,3]))


```

```python

#convert the first and last word in upper alphabate

array = "heello how are you"

array = array.split('')

def element(array):
    for element in(array):
    print(elemnt[0].upper() + elemnt[1:-1] +elemnt[-1].upper(),end = '')
```

 ```python

#check if list is in sorted order 
```

```python

## FIND INTEGER VALUES FROM EACH ELEMENT WITHOUT USING LOOP

list = [ "30 student, 5 teacher, 1 pricipal" ]

 for i in list:
 l =int(i.split()[0]) 
 print(l)
  
```