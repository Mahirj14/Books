#python [[PYTHON]]

```python
#this code for genreate square for 1-10
sqaures = []

for i in rangesc(1,11):
	square = i ** 2
	sqaures.append(square)

print(squares)

```

>Tuple

(10,20)
- you cant the change the value of tuple

```python
users = [ 'mahir', 'indu','admin','aws','azure']
new_users = ['mical','eni','ela','mahir','cipcy']
match = []

for user in users:
    if user in new_users:
        #match.append(user == new_users)
        
        print(f'hi {user} would you like status report!')
    else:
        print(f'hi {user} thank you for logging!!')
        
print(match)
```

if>elif>else


> Dictionary

- can store an almost limitless amount of information.

> user input



