[[PYTHON]]


function-parameters-arguments

```python

def list_namae(name,location):
	print( f" he is {name}")
	print( f" today weather is beautiful isnt it {location}")

list_name(name="mahir",location="BHGLR")
```

### Comparison: Django vs. Flask

- **Django** is ideal for larger applications where you need a lot of built-in features and don't want to spend time integrating third-party tools.
- **Flask** is great for smaller projects or for developers who want more control over the components of their application and prefer to integrate tools themselves.