 [[Apache Spark notes]]


#partitionsvsbucketing

Certainly! Let's start with explaining both concepts and then dive into real-world examples and when to use each.

> **Partitioning:**

Partitioning is the process of dividing a large dataset into smaller and more manageable parts based on certain criteria. 

**Real-world Example:**

Consider a large e-commerce website that collects vast amounts of data about customer transactions. This data might include information such as customer ID, product ID, purchase date, purchase amount, etc. Partitioning this dataset by the purchase date can be a common strategy. Each partition would contain all the transactions that occurred on a particular date. This partitioning scheme can facilitate efficient querying and analysis of transaction data, especially if the application frequently needs to retrieve or process data for specific time periods.

**When to Use:**

Partitioning is beneficial when:

1. **Data Skew:** Partitioning helps distribute data evenly across processing nodes, reducing the risk of data skew and improving parallelism.


>**Bucketing:**

Bucketing is a technique used to further organize data within partitions by grouping it into smaller subsets called buckets based on a hash function applied to one or more columns. 

**Real-world Example:**

Continuing with our e-commerce example, let's say we want to further organize our transaction data within each partition by bucketing it based on the product category. We might define a hash function to hash the product category column values and group them into, for example, 10 buckets. This bucketing scheme can help optimize queries that involve filtering or aggregating data based on product categories within specific date partitions.

**When to Use:**

Bucketing is useful when:

1. **Data Distribution:** Bucketing can improve data distribution within partitions, especially when certain values are more heavily represented than others.
2. **Join Performance:** Bucketing can improve join performance, particularly in scenarios where joins are performed on columns that are bucketed and both tables have the same bucketing scheme.


```python

# Example of partitioning by a column in PySpark
from pyspark.sql import SparkSession

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("Partitioning Example") \
    .getOrCreate()

# Read data from a CSV file
df = spark.read.csv("data.csv", header=True)

# Partitioning the DataFrame by the 'category' column
df.write.partitionBy("category").parquet("partitioned_data")

 #Bucketing the DataFrame by the 'id' column into 10 buckets 
 df.write.bucketBy(10, "id").saveAsTable("bucketed_table", format="parquet", mode="overwrite")
 
# Stop SparkSession
spark.stop()

from pyspark.sql impoert sparksession
spark = sparksession.builder\
		.appname("accenture") \
		.getOrcreate()
df = spark.read.csv("data.csv, header = true, inferschema = true)

					spark.stop()
		
```

- when do saveastable then managed table
- when u do give path then its extrnal table
- joining perfomance very good after bucketing


```python
# explode() on array column

from pyspark.sql.functions import explode
df2 = df.select(df.name,explode(df.knownLanguages))

from pyspark.sql.function import explode
df2 = df.select(df.name, explode(df.knownlanguages))
```


> dropping null


df.drop.na(subset =["email"])



#fill
df.fill.na("avg_sal", ["salary"])

> string manupaltion

df.withcolumn("cleaned", regex_replace("discription", "[^a-zA-Z0-9\\S]", "" ))   

#lowwer/upper

df.colummnwith("upper", lower("product_name"))

#cast

```python

Casting to Integer or Long:  
  
 df = df.withColumn("integer_column",col("string_column").cast("int"))  
  
2. Casting to Double or Float:  
  
 df = df.withColumn("double_column",col("string_column").cast("double"))  
  
3. Casting to String  
  
 df = df.withColumn("string_column",col("numeric_column").cast("string"))  
  
4. Casting to Timestamp  
  
 df = df.withColumn("timestamp_column", to_timestamp(col("timestamp_str"), "yyyy-MM-dd HH:mm:ss"))

#string to timestamp
df = df.withcolumn("month" , to_timestamp(col("time_str"), "dd-mm-yyyy")

#finding month|year				   
df = df.withcolumn("month" , month(col("timestamp"))
)


df = df.withcolumn("session_time" , (unix_timestamp(col("end_session")) -unix_timestamp(col("start_session")) ) #calculte in second
```


```
#datediff
#dateadd 
```


#salting in data


#Deltatable

> what is upstream data signify and what downstream data help to  team 

> data qwality checks
> 

> Constant folding:

compile time identifiable constant expression are computed and replaced with their resultant values.
 this reduces the need for computation during query execution.



> >  Daynamic partition prunning

Dynamic Partition Pruning (DPP) is a technique used in query optimization within databases to reduce the amount of data scanned during query execution. It's particularly useful in scenarios where there are large datasets partitioned across multiple storage locations or partitions.

Here's how Dynamic Partition Pruning works with an example:

Let's say you have a database table called `sales_data`, which contains information about sales transactions. This table is partitioned by date, with each partition representing data for a specific day. So you might have partitions like `sales_data_2024_04_24`, `sales_data_2024_04_25`, and so on.

Now, imagine you have a query that needs to retrieve sales data for a specific date range, say from April 1st, 2024, to April 15th, 2024. Without partitioning, the database engine would need to scan the entire `sales_data` table to find the relevant rows, which can be inefficient and time-consuming, especially if the table is large.

However, with Dynamic Partition Pruning, the query optimizer can analyze the query predicate (the condition in the WHERE clause) and determine which partitions contain the relevant data. In our example, it knows that it only needs to scan partitions `sales_data_2024_04_01` to `sales_data_2024_04_15` because those are the only partitions that could possibly contain the data within the specified date range.

By leveraging this information, the query optimizer generates an optimized query plan that only scans the relevant partitions, thereby reducing the amount of data accessed and improving query performance.

In essence, Dynamic Partition Pruning dynamically prunes away unnecessary partitions based on the query predicate, allowing for more efficient data retrieval. This technique is especially beneficial in scenarios with large partitioned datasets, where traditional full-table scans would be impractical.


>predict pushdown

> projection pushsown

> dynamic partition pruninig



> SparkUI (METRIX)

- Task duration
- shuffle read/write times
- executor CPU and memory utilization
- garbage collection
- stage duration
- resource utilization
