[[Pyspark command]]  [[Apache Spark notes]]

---
source 
transformation
optimization
destination


DATA PROFILING 
- check missing values (like NULL)
- unqiue values & freqency
- range(min,max,avg)

> we before used great expectation but  moved aws glue data catalog itself for data quality

>  34% cheaper

> **Error record identification**

> `ReferentialIntegrity`, `DatasetMatches`, `RowCountMatches` `AggregateMatches`, SchemaMatch 

.. budling on apache spark >> DeepQ which biggest competitor of great expectation

|                           |                                                                                                                                                                 |
| ------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `AggregateMatch`          | Checks if two datasets match by comparing summary metrics like total sales amount. Useful for customers to compare if all data is ingested from source systems. |
| `ColumnCorrelation`       | Checks how well two columns are corelated.                                                                                                                      |
| `ColumnCount`             | Checks if any columns are dropped.                                                                                                                              |
| `ColumnDataType`          | Checks if a column is compliant with a data type.                                                                                                               |
| `ColumnExists`            | Checks if columns exist in a dataset. This allows customers building self-service data platforms to ensure certain columns are made available.                  |
| `ColumnLength`            | Checks if length of data is consistent.                                                                                                                         |
| `ColumnNamesMatchPattern` | Checks if column names match defined patterns. Useful for governance teams to enforce column name consistency.                                                  |
| `ColumnValues`            | Checks if data is consistent per defined values. This rule supports regular expressions.                                                                        |
| `Completeness`            | Checks for any blank or NULLs in data.                                                                                                                          |
| `CustomSql`               | Customers can implement almost any type of data quality checks in SQL.                                                                                          |
| `DataFreshness`           | Checks if data is fresh.                                                                                                                                        |
| `DatasetMatch`            | Compares two datasets and identifies if they are in sync.                                                                                                       |
| `DistinctValuesCount`     | Checks for duplicate values.                                                                                                                                    |
| `Entropy`                 | Checks for entropy of the data.                                                                                                                                 |
| `IsComplete`              | Checks if 100% of the data is complete.                                                                                                                         |
| `IsPrimaryKey`            | Checks if a column is a primary key (not NULL and unique).                                                                                                      |
| `IsUnique`                | Checks if 100% of the data is unique.                                                                                                                           |
| `Mean`                    | Checks if the mean matches the set threshold.                                                                                                                   |
| `ReferentialIntegrity`    | Checks if two datasets have referential integrity.                                                                                                              |
| `RowCount`                | Checks if record counts match a threshold.                                                                                                                      |
| `RowCountMatch`           | Checks if record counts between two datasets match.                                                                                                             |
| `StandardDeviation`       | Checks if standard deviation matches the threshold.                                                                                                             |
| `SchemaMatch`             | Checks if schema between two datasets match.                                                                                                                    |
| `Sum`                     | Checks if sum matches a set threshold.                                                                                                                          |
| `Uniqueness`              | Checks if uniqueness of dataset matches a threshold.                                                                                                            |
| `UniqueValueRatio`        | Checks if the unique value ration matches a threshold.                                                                                                          |


> managed table

 Managed tables are the default type of table in Spark and are typically used when you want Spark to handle the entire lifecycle of the table, from creation to data storage and cleanup.
scema+tabel data
droping table its lost meta data also

> external table

On the other hand, external tables are designed to access data stored outside of Spark’s control. In an external table, Spark manages only the metadata (schema) in its internal catalog, while the actual data resides in an external storage system like HDFS, S3, or a relational database.

only meta data
only lost meta data not data/



> Kryo serialization -

if object is large, prefer caching in serialized form - as serialized object require less storage.  
Use Kryo serialization if you want to cache data in serialized form, as it leads to much smaller sizes than Java serialization.


> in spark running job if we stop spark context then what happen?

In Apache Spark, when you stop the SparkContext, it means that you are terminating the Spark application and releasing all the resources that were acquired by the application, such as the executor processes, memory, and other resources.

1. **Job Cancellation**: Any currently running jobs or tasks within the Spark application will be canceled and terminated immediately. This includes any transformations or actions that were in progress.
2. **Resource Release**: All the resources that were allocated by the Spark application, such as executor processes, memory, and other cluster resources, will be released and made available for other applications to use.
3. **Cached Data Loss**: Any data that was cached in memory or on disk by the Spark application will be lost and need to be recomputed if required again.
4. **Metadata and Configuration Loss**: Any metadata or configuration settings that were specific to the Spark application, such as broadcast variables, accumulators, or custom configuration properties, will be lost.
5. **Spark UI and Logs**: The Spark Web UI and any log files associated with the application will become unavailable or be archived, depending on the cluster configuration.

It's important to note that stopping the SparkContext is a terminal operation, and the Spark application cannot be resumed from the same state after stopping it. If you need to continue working with the same data or computations, you'll need to create a new SparkContext and re-initialize your application.

> what are the modes in which spark application can be deplyoed?

- standalone
- YARN yet another resorge nrgotiaterthe driver program would be launched on any one of the spark cluster nodes (on any of the available nodes in the cluster). Cluster deployment is mostly used for large data sets where the job takes few mins/hrs to complete.
 -  Terminating the current session doesn’t terminate the application. The application would be running on the cluster. You can get the status of the spark application by running `<strong>spark-submit --status [submission ID]</strong>`
- Since Spark driver runs on one of the worker node within the cluster, which reduces the data movement overhead between submitting machine and the cluster.
- For the Cloudera cluster, you should use yarn commands to access driver logs.
- In this spark mode, the change of network disconnection between driver and spark infrastructure reduces. As they reside in the same infrastructure(cluster), It highly reduces the chance of job failure.
ental **Cloudera cluster**, you submit the Spark application from the Edge node hence the ill run on an edge node.ault deployment mode is client mode.
- In client mode, if a machine or a user session running **spark-submit** terminates, your application also terminates with status fail.
- Using Ctrl-c after submitting the spark-submit command also terminates your used for Production jobs. This is used for testing purposes.
- Driver logs are accessible from the local machine itself.

> pushdown predicthe context of Spark or other data processing frameworks, pushdown predicates are used to minimize data movement and improve query performance by filtering data at the source before it is fetched into memory for further processing.

>Upsert

- The term "upsert" is a combination of "update" and "insert".
- - "Upsert" is a database operation that either updates a row if it already exists in the database or inserts a new row if the row does not exist.

#### Star Schema

In the star schema design, a single object (the fact table) sits in the middle and is radically connected to other surrounding objects (dimension lookup tables) like a star.  
Each dimension is represented as a single table.  
The primary key in each dimension table is related to a foreign key in the fact table.  

All measures in the fact table are related to all the dimensions that fact table is related to.  
In other words, they all have the same level of granularity.  

A star schema can be simple or complex.  
A simple star consists of one fact table; a complex star can have more than one fact table.  

#### Snowflake Schema

It is an extension of star schema.  
In a star schema, each dimension is represented by a single dimensional table, whereas in a snowflake schema, that dimensional table is normalized into multiple lookup tables, each representing a level in the dimensional hierarchy.  

Adv -  
improvement in query performance due to minimized disk storage requirements and joining smaller lookup tables.  

Disadvantage-  
additional maintenance efforts needed due to the increase number of lookup tables.


### Salting to Mitigate Data Skew

Salting is a technique used to mitigate data skew by redistributing skewed data more evenly across partitions. The idea is to add a random "salt" (a small random value) to the keys, thus spreading the values associated with heavily skewed keys across multiple partitions.

Data skew can severely impact the performance of PySpark jobs by causing uneven load distribution across partitions. Salting is an effective technique to mitigate data skew by redistributing data more evenly. By understanding and applying salting, you can improve the performance and efficiency of your PySpark applications, especially when dealing with highly skewed datasets.


### What is LRU?

Least Recently Used (LRU) is a caching mechanism that keeps track of the usage of items in the cache and evicts the least recently accessed items first. The main idea is that items that have not been used for a long time are less likely to be used in the future, so they are removed from the cache to make room for new items.
ow LRU is Used in PySpark

In PySpark, when you persist an RDD in memory, the storage mechanism uses an LRU policy to manage the limited memory resources. This is particularly relevant when you use storage levels such as `MEMORY_ONLY` or `MEMORY_AND_DISK`.




-- its **lazy evaluation** framework. This means transformations aren’t executed until an **action** is called. But what if I told you there’s a way to expedite this process

>eagaereval
> spark.conf.set("spark.sql.repl.eagerEval.enabled",True)


> df.limit(1).show()
> --showing all columns 


--In order to avoid throwing an out-of-memory exception, use `DataFrame.take()` or `DataFrame.tail()`

> dir(df)

: UDF 
: Genrtor, iterator
: how to read data from URL?


