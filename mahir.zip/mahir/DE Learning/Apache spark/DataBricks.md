[[Apache Spark notes]]

> Delta Lake

> Delta live table

>unity catalog

> Auto loader 

> Photon

