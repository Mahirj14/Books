[[Pyspark command]]

#Outofmemorey 

> Driver memory config,   *solu :spark-submit--conf spark.driver.memory =4g


> collecting large result sets  solu:  avoid using collct

> Broadcasting variable :    solu:  use cache

> complex driver-side operation :   scale horizonatllly



Reserved Momery: 300mb

user memory : 40% - data lineage-RDD-Udfs

          Unified memory: main space where actions is lhappening
         storage memory: cache

          execuation memory : hash, partition, shuffle

![[spark memory mang.png]] 