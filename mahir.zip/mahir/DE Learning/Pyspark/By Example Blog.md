[[Pyspark command]]

#withcolumnrenamed
```python

df.withColumnRenamed("dob","DateOfBirth") #simple rename command




df2 = df.withColumnRenamed("dob","DateOfBirth") \   #multiple rename
.withColumnRenamed("salary","salary_amount")



df.select(col("name.firstname").alias("fname"), \  #using select for nested rename
  col("name.middlename").alias("mname"), \
  col("name.lastname").alias("lname"), \
  col("dob"),col("gender"),col("salary")) \
  .printSchema()



df4 = df.withColumn("fname",col("name.firstname")) \ #withcolumn nested
      .withColumn("mname",col("name.middlename")) \
      .withColumn("lname",col("name.lastname")) \
      .drop("name")
df4.printSchema()



```


#withcolumn
```python

df.withColumn("salary",col("salary").cast("Integer")).show() #str to int datatypes



df.withColumn("salary",col("salary")*100).show()  #update the value of existing column



df.withColumn("Country", lit("USA")) \           #lit for adding constant value
  .withColumn("anotherColumn",lit("anotherValue")) \
  .show()



# Using equals condition filter command
df.filter(df.state == "OH")



```

#filter

```python

# Using equals condition filter command
df.filter(df.state == "OH")

# Using SQL Expression
df.filter("gender == 'M'").show()
#For not equal
df.filter("gender != 'M'").show()
df.filter("gender <> 'M'").show()


# Filter multiple condition
df.filter( (df.state  == "OH") & (df.gender  == "M") ) \
    .show(truncate=False) 

# Filter NOT IS IN List values
#These show all records with NY (NY is not part of the list)
df.filter(~df.state.isin(li)).show()



# Using startswith
df.filter(df.state.startswith("N")).show()

#using endswith
df.filter(df.state.endswith("H")).show()

#contains
df.filter(df.state.contains("H")).show()




# Struct condition nested name
df.filter(df.name.lastname == "Williams") \
    .show(truncate=False)

```

#sort/orderby
```python

df.sort("department","state").show(truncate=False)



df.sort(col("department").asc(),col("state").asc()).show(truncate=False)
df.orderBy(col("department").asc(),col("state").asc()).show(truncate=False)


```

