[[Pyspark command]]

```python
# Import PySpark AI
from pyspark_ai import SparkAI

# Create SparkAI
spark_ai = SparkAI()
```
Following are the parameters to SparkAI() you can use.

|                           |                                                                                                  |
| ------------------------- | ------------------------------------------------------------------------------------------------ |
| llm                       | Used to set the LLM model you wanted to use                                                      |
| web_search_tool           | By default, it uses Google search to perform web search                                          |
| spark_session             | To set an existing SparkSession. A new one will be created if not provided                       |
| enable_cache              | Specify whether to enable caching of results                                                     |
| cache_file_format         | optional str, format for cache file if enabled                                                   |
| vector_store_dir          | To specify directory path for vector similarity search files,  <br>if storing to disk is desired |
| vector_store_max_gb       | Set the max size of vector store dir in GB                                                       |
| max_tokens_of_web_content | maximum tokens of web content after encoding                                                     |
| sample_rows_in_table_info | Used only with SQL transform to set number of rows to be sampled. Use 0 to disable this          |
| ==verbose==               | Use to print out the log                                                                         |


```python
# Activate
spark_ai.activate()
```


```python

# Create DataFrame from web
df = spark_ai.create_df("https://www.visualcapitalist.com/the-worlds-tech-giants-ranked/")
df.show()
```
```python
# Apply transformation using english language
df2 = spark_ai.transform_df(df,"rank company by value for each country")
df2.show()
```

```python
# Apply transformation using english language
df3 = spark_ai.transform_df(df2,"get top company by value from each country")
df3.show()
```

```python
# Verify DataFrame result
spark_ai.verify_df(df3, "make sure the result contains 4 records")
```
```python
# Explain DataFrame
spark_ai.explain_df(df3)
```

```python
# Plot chart
spark_ai.plot_df(df3)
```

```python
# pie chart
spark_ai.plot_df(df3,"pie chart")
```

```python
# Commit / used to persist staging in-memory cache into the persistent cache, if the cache is enabled
spark_ai.commit()
```
