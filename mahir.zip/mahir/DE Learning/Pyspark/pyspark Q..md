[[Pyspark command]]


>>> merge uneven column numbers


- `introducee null coulumn,union

```PYTHON
from pyspark.sql.functions import col, lit

df2.withcolumn("department",lit("null"))
df1.union(df2) 
```

>>> convert dataframe to sql 
>>> 
``` sql
 df1.createOrReplaceTempview("department") 
 spark.sql("select * from table")

```


> convert multiple raws into single column

``` python
df.gorupby("Name").agg(collect_list("language")).show()
```

> convert multiple coulmns into single row
- ==explode()== function



==*joins
```python
df_joined = df1.join( df2, df1.id = df2.id, inner)
```



> Write a Spark code snippet to calculate the sum of a salary in a DataFrame



>*Identify rows containing non-numeric values in the "Quantity" column, if any.




>*Find out hashtag count for each quote




>*Write a PySpark program to select every 3rd (nth) row in the dataset



  
>*Write a pyspark code to rank the products based on their total sales amount for each month, and return the top product for each month



  
>*Employee salary greater than Manager Id



  
>*Find Duplicate Emails
  
>*Find the missing numbers in the column



  
>*Write a Pyspark program to format the scientific notation, and show them as decimal numbers



>*Total Partitions and Total Rows in Each Partitions



  
>*Find year,start_week_date,end_week_date,week_num



  
>*You are given a fixed length text file. Your task is to create multiple columns from the single row



  
>*Write a PySpark program to augment this dataframe with two additional columns: 'std_code' and 'landline'.


  
>*Save Integer and Array Data into the DataFrame


>*Find the accounts that should be banned. An account should be banned
 if it was logged in from two different IP addresses at any moment.


>Q. We have a table with employees and their salaries, however, some of the records are old and contain outdated salary information. Find the current salary of each employee assuming that salaries increase each year. Output their id, first name, last name, department ID, and current salary. Order your list by employee ID in ascending order.

```python

result = ms_employee_salary.groupBy('id','first_name','last_name',"department_id",).agg(F.max('salary').alias('salary')).sort('id').toPandas()

result
```









```PYTHON
import pyspark.sql.functions as F

title_worker_id = title.withColumnRenamed("worker_ref_id", "worker_id")

merged_df = worker.join(title_worker_id, on="worker_id")

max_salary = merged_df.filter(F.col("salary") == merged_df.select(F.max("salary")).first()[0]).select("worker_title").withColumnRenamed("worker_title", "best_paid_title")

max_salary.show()
```




> Write a query that calculates the difference between the highest salaries found in the marketing and engineering departments. Output just the absolute difference in salaries.


```python

db_employee = db_employee.join(db_dept, db_employee['department_id'] == db_dept['id'])\
    .filter(db_dept['department'].isin(['engineering', 'marketing'])) \
    .groupby() \
    .pivot('department') \
    .agg(F.max('salary')) \
    .select(F.abs(F.col('engineering') - F.col('marketing')).alias('salary_difference'))

```

> write pyspark code for the 2nd highest salary.

```python

df.withcolumn("rank, rank().over(orderby = col("sal").desc())) \
.where(col("rank") == 2) \
.select("name", "salary") \
.show()
```

```python
#find total_revunue by each customer only order_statue= complete


joined_df = orders.join(orderitems, on = "order_id", how = left)\
            .groupBy("customer_id" )\
            .agg(sum (when (col("order_statue") == "complete", col("qyantity") *col(unit_price").otherwise(0))
```

> while you do inferschema = true then it will create job and take time

> while in  custom schema it run fast without create any job



>json_tuple

df = df.select('device', json_tuple(df.prop, 'RAM').alias ('RAM'))

> get_json_object

df = df.select('device', get_json_object(df.props, '$.props.RAM'))

give nested loop RAM coloumn

>LRU (least resource used)

while its data spilled or when caches reached its capacity
