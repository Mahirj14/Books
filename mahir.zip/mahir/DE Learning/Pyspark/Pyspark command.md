#pyspark #command #session

**Creating session**


```python

from pyspark.sql import sparkSession  #session 

spark = sparkSession.Builder /        #builder
        .appName("Deloitte") /
        .getOrCreate();

schema = structType ([                    
                     structField("id", stringType(),True)     #cutomschema
                     structField("id", stringType(),True)
                     ]);

df= spark.read.csv("original.csv" Header = True inferSchema = True); #reading
```



```python

#joins function

df_joined = df2.join(df1, df2.key=df1.key ,inner)
add-df = df.withcolumn( "newcol", .agg(col1 +col2))

```

```python

#filter condition

df.select(col("track"),col("artist"))
df.select(*) filter(df.artist == "rihana")
```

```python

#when condition

df.withcolumn(
             "gender",when(col("gender") == "f" then "female")
                      .when(col("gender") == "M" then "male")
                      .otherwie ("unknown")
              )  

```
```python

df.createOrReplaceTempview("table")   #[Using sql command] 
result = spark.sql( select * from table)
table.show()

```



>Q1 : read the address as street_name, city_name, country_name?

```python
from pysparl.sql.function import split

df.withcolum("street_name", split("emp_add", ",")[0]) \
       .withcolum("city_name", split("emp_add", ",")[1]) \
           .withcolum("country_name", split("emp_add", ",")[2])

```


>Q2 : Get student id of student who topped in the respective subjects


```python

window_func = window().partitionBy("subject").orderby(f.desc("marks")

intermediat_df =  df.withcolumn("rank" , f.rank().over(window_func))

intermediat_df.show()


win_fun = winmdow().partitonby("subkect").orderby(f.desc("maarks"))
ont_df = df.withcolumn('rankk", rank().over(win_fun))
					ont_df.show()

													
													  ```

win_fun = window().partitinby("subject").orderby(desc"mark")
int_result = df.withcolu,m("rank" , rank()over(win_fun))


Q3 : Suppose you have a dataset with information about employee projects, 
   and you want to find the most recent project 
   and the total number of projects for each employee. 

```python
df.grouBy("emp_id")
  .agg(  df.last .alias recent_project,
         df.count . alais proects
)

```

Q4: select name ,age from details nested loop
 
```python

df.withcolum("name", df[details.name])

df.withcolum("age", df[details.age])
```



```python

# Saving modes
df2.write.mode('overwrite').csv("/tmp/spark_output/zipcodes")


df.write.formate("parqet")\
  .mode('overwrite')\
  .option('compression','sannapy')\
  .bucketby(3,'maem')\
  .saveAsTable(output.parweqt)
  
```


```python

#two nested loop 
df.select(df.name,explode(df.subject).show() # expldoe column
df.select(df.name,flatten(df.subject)).show() #flatten into string
```


```python
from pysparl.swl.functions import collect_set

df2 = df.grouBy("name").agg(collect_list("langauges")).alias)("language") 
df2 = df.grouBy("name").agg(collect_set("langauges")).alias)("language")#remove duplicates
```


> split one th bases of - and / 


| Playner      | 50/100s |
| ------------ | ------- |
| sachin - IND | 45/95   |
| maxwell - NL | 44/90   |

```python

df = df.withcloum('playername', split(df.['player'], '-' ).getitem(0) ) \
          df.withcloum('50/100s', split(df.['player'], '/' ).getitem(0) )


```



| count | string | str_cnt |
| ----- | ------ | ------- |
| 4     | R      | RRRR    |

```python

select *, Replicate(count,string)
from test_tbl
```



```python

#for using pandas in pyspark

import pandas as pd
#as it is n pyspark

#sparksession as it is
pandas_df = pd.read_csv("data.csv")


spark_df = spark.createDataFrame(pandas_df)

.
.
.#transformation in spark
.
.

pandas_df = spark_df.toPandas()


spark.stop()



```

```python
 #for seperate by ||
 
val df = spark.read.format("csv") 
.option("header",true) 
.option("sep","||")
.load("/FileStore/tables/emp_data.txt")
```

```python

#converstring date to date datatypes

 df.select(to_date("rechargedate").cast("string"),"yyyymmdd"))

df.select(expr ( "date_add(recharble,remainingdays)"))
```

> *- Use `accumulators`  which can be helpful in debugging by tracking the state of variables across the cluster.*

> - **Salting**: Add a random prefix to the keys that are causing skewness to distribute the data more evenly.

> collect_set 

- for combining all values 