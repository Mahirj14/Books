[[Pyspark command]] #pyspark 


 ``` python
  spark = SparkSession.builder \
       .appName("MySparkApp") \
       .getOrCreate()
```
  

2. **Loading Data**:
   PySpark can read data from various sources like text files, CSV, JSON, Parquet, etc.
   ```python
   df = spark.read.csv("file.csv", header=True, inferSchema=True)
```
   

3. **Viewing Data**:
   To view the data in a DataFrame:
   df.show()
   

4. **Schema**:
   To view the schema of the DataFrame:

     ```python
 df.printSchema()
```
 

5. **Selecting Columns**:
   You can select specific columns from a DataFrame:

 ```python
 df.select("column1", "column2")
```
  

6. **Filtering Data**:
   Filtering rows based on a condition:


   ```python
df.filter(df["column1"] > 50)
```
   

7. **Grouping and Aggregating**:
   You can group and aggregate data using functions like `groupBy` and `agg`:

```python
   
   df.groupBy("category").agg({"value": "avg"})
```
  

8. **Sorting Data**:
   Sorting data in ascending or descending order:

   ```python
   df.orderBy("column1", ascending=False)
```
   

9. **Creating Temporary Views**:
   You can create a temporary SQL view from a DataFrame:

```python
   df.createOrReplaceTempView("mytable")
```
   

10. **Running SQL Queries**:
    You can run SQL queries on DataFrames:

     .
    ```python
result = spark.sql("SELECT * FROM mytable WHERE column1 > 50")
```
      

11. **Saving Data**:
    Saving data to various formats:

     .
    ```python
df.write.csv("output.csv")
```
      

12. **Caching Data**:
    Caching DataFrames in memory for faster access:

     .
```python
    df.cache()
```      

13. **Counting Rows**:
    To count the number of rows in a DataFrame:

     .
```python
    df.count()
```      

14. **Iterating Over Rows**:
    PySpark DataFrames can be iterated over:

     .
```python
    for row in df.rdd.collect():
        print(row)
```      

15. **UDF (User-Defined Functions)**:
    You can define and use UDFs to apply custom functions to DataFrames:

     ``` python
    from pyspark.sql.functions import udf
    from pyspark.sql.types import IntegerType

    square_udf = udf(lambda x: x*x, IntegerType())
    df.withColumn("squared", square_udf(df["value"]))
```


> so many columns datatypes change in one go


# Loop through each column and change its data type to integer
```python

columns = df.columns 

for col_name in columns: df = df.withColumn(col_name, col(col_name).cast("integer"))

```

> **there are 5000000 records What would be the best practice to write code.Would you be processing 5000000 records in each line of code?**

**Answer :** In that case we can use limit function(say 1000 records ) ,cache it and then use it . And when the complete code is ready we can process all data.


 > iS it possible to load images in spark dataframe ?

**Answer** Yes using below command

spark.read.format(“image”).load(“path of image”)
 
- RDD.unpersist() method will delete the cached data.


> **How will you convert rdd to df?**

  mydf=spark.createDataFrame(myrdd,schema)


> **How would you limit the number of records (say 1000) in spark dataframe.**

**Answer** : You can use df.limit(1000) function to limit the number of rows



> **What happens to spark application which you have run using spark submit and then press ctrl+c .Consider two cases :**

**A. If deploy mode is client**

**B. if deploy mode is cluster.**

**Answer** : When submitted in client mode the driver runs on the machine through which you have submitted the spark application. So when ctrl+C has pressed ,it kills the whole application because driver’s execution is killed. Unlike in cluster, mode driver runs on cluster’s Worker nodes.Hence even if you press ctrl+c ,it will keep on running.


>  **Suppose you have a spark dataframe which contains millions of records. You need to perform multiple actions on it. How will you minimize the execution time?**

**Answer** : You can use cache or persist


> **Suppose you have two dataframe df1 and df2 , both have below columns :-** 

df1 =>  id , name, mobno

df2 => id ,pincode, address, city

After joining both the dataframe on the basis of key i.e id , while  selecting id,name,mobno,pincode, address, city, you are getting an error ambiguous column id. how would you resolve it ?

 joined_df= df1.join(df2,df1("id") == df2("id")).drop(df2("id"))



> Scenario: You have a very large DataFrame "big_df" with millions of rows. Implement a sampling technique to select a random sample of 1% of the data and display the sampled DataFrame.

```python
# Sample 1% of the data
sampled_df = big_df.sample(withReplacement=False, fraction=0.01)

sampled_df.show()
```