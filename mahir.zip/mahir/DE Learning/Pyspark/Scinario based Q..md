[[SQL command]]


> scenario 10

- convert string type into date types using (to_date)
- then (add_date) sum the days

> scenario 12

We will learn how Apache Spark itself handles the slow or long running task. What is Speculative Execution?

stag1 - task1,task2
stag2 - task3, task4

task 1,3,4 running on time but somehow task2 is delayed so task2 give to other executor and run there and finish asap that is call speclative execuation.


 >scenario 14
 
 we will learn how to handle the corrupted records in our dataset
    - fail fast = it will not read file
    - permissive = create new column for currput record
    - Dropmalformed = drop that column



 df= spark.read.csv("path.csv", inferchema= true, header = true).option("mode" = "passive")
 
df.spark.read.option('mode' = 'permissive')
             .option('inferschema', 'true')
             .option('header', 'true')
             .load('path.csv:')


> scenario 14

coleasc is reduce partition not increase

>  scenario 15

map/flatmap

mahir, pune
umesh, mumbai

map = 2 count
fmap = 4 count


> scenario 16
how to flatten the JSON format string column inside a CSV file

reqest is nested loop in json

- json_tuple

```python

df.select("*", json_tuple("request", "resopnse")).drop("request") \
   .select("*", json_tuple("c0" , "messgeid","lattitude", "longitude")).drop("co")
```


> scenario 17

if you wanna commne record from both table you can get by
- union
- substract
- left anti join

> scenario 18

if you want transpose column to row then you can use pivot ,groupby agg

> scenario 19

win_spec = window.partitionBy("department").orderBy("salary")

ind_result = df.withcolumn('row number' , row_number().over(wind_spec)).show()


> scenario 20

explode outer will give null value also 
but you have to split > the expldoe_outer


> scenario 21

without count command how can you do count?
you can use shared variable accumaltors


> scenario 22

Interviewer: Let's discuss a scenario where we need to remove columns from a DataFrame that have more than 90% null values. Have you encountered such a task before?
Candidate: Yes, I've worked on similar tasks. We often need to clean up data by removing columns with excessive null values to improve data quality and analysis. Interviewer: Great. How would you approach this task in PySpark? 

Candidate: Firstly, ld calculate the percentage of null values in each column. Then, l'd filter out columns where the null percentage exceeds 90%. Finally, I'd remove those filtered columns from the DataFrame

 Interviewer: Can you walk me through the code for this process?
 
  # Calculate the percentage of null values in each column
    total_rows = df.count() null_percentages [(col_name, df.where(col(col_name).isNull).count() / total_rows 100) for col_name in df.columns]
  
   # Filter out columns with more than 90% null values
    columns_to_drop = [col_name for col_name, nullLpercentage in null_percentages if null_percentage > 90] 
   
   # Remove columns with more than 90% null values
    df_filtered df.drop(*columns_to_drop)