
This chapter focuses on designing a system that can support millions of users. Beginning with a single-server setup, the chapter gradually scales the system up by adding components and optimisations.

>**Single server setup**

The simplest design uses just one server that handles all the functionality: web app, database, cache, etc.

As the user base grows, a single server isn’t sufficient, so multiple servers are needed. A **web tier**, consisting of multiple web servers, handles user traffic, while a **data tier**, comprising multiple database servers, handles database operations.

>**Load Balancer**

A load balancer is added to distribute traffic evenly among web servers, improving system availability. It sits in front of the web servers and ensures that if one server fails, users can still access the website.

>**Database Replication**

Database replication is introduced, using a **master database** for write operations and **slave databases** for read operations. This setup improves read performance and ensures data availability even if one database server fails.

>**Cache**

A **cache tier** is added to improve system performance and reduce database workload. This tier stores frequently accessed data in memory for faster retrieval. To mitigate failures, using multiple cache servers across different data centers is recommended to avoid a single point of failure. Overprovisioning memory provides a buffer for increased memory usage.

> **Content Delivery Network (CDN)**

A CDN is used to cache static content like JavaScript/CSS/images/videos. CDN servers are geographically distributed, so content is delivered from a server closer to the user, improving load times.

>**Stateless Web Tier**

The web tier is made stateless by moving session data out of web servers and into a persistent storage like a database or NoSQL data store. This makes the system more scalable and robust.

>**Multiple Data Centers**

To improve availability for a global user base, the system is expanded to support multiple data centers. Users are routed to the nearest data center using geoDNS, which resolves domain names to IP addresses based on user location.

>**Message Queues**

Message queues are introduced to make the system more loosely coupled and resilient to failures. They act as intermediaries between system components, enabling asynchronous communication.

>**Database Scaling**

As data grows, the database is scaled using either vertical or horizontal scaling.

**Vertical scaling** involves adding more power to an existing machine (CPU, RAM, etc.). However, this approach has limitations due to hardware limits and increased risk of single points of failure.

**Horizontal scaling** involves adding more servers, a technique known as sharding. Data is divided into smaller, manageable parts called shards, each with the same schema but unique data. Sharding improves scalability but introduces challenges like data resharding and the celebrity problem (hotspot key problem).

The chapter ends with a summary of techniques for scaling a system to millions of users:

- Keep the web tier stateless.
- Build redundancy at every tier.
- Cache data as much as possible.
- Support multiple data centers.
- Host static assets in a CDN.
- Scale the data tier by sharding.
- Split tiers into individual services.
- Monitor your system and use automation tools.




Here is a step-by-step guide on how to scale a system from zero to millions of users, in brief:

- **Begin with a single-server setup**: This is your starting point where a single server handles all functionality.
- **Introduce multiple web servers (web tier)**: As traffic increases, a single server becomes insufficient. Add more web servers to handle user traffic.
- **Add a load balancer**: A load balancer distributes traffic evenly among the web servers, preventing overload and ensuring availability.
- **Implement database replication**: Use a master database for writes and slave databases for reads to improve performance and availability.
- **Introduce a cache tier**: Caching frequently accessed data in memory improves system performance and reduces the load on the database.
- **Utilise a Content Delivery Network (CDN)**: Host static content (images, CSS, JavaScript) on a CDN to deliver it quickly to users globally.
- **Make the web tier stateless**: Move session data out of the web servers and into a shared data store to improve scalability and robustness.
- **Expand to multiple data centers**: For a global user base, support multiple data centers and route users to the nearest one for better performance.
- **Add message queues**: Decouple system components using message queues to improve fault tolerance and enable asynchronous communication.
- **Scale the database horizontally (sharding)**: As data grows, divide the database into smaller parts (shards) and distribute them across multiple servers.
- **Monitor and optimize**: Continuously monitor system performance, identify bottlenecks, and use automation tools for efficient management.

By following these steps, you can scale your system effectively to accommodate millions of users and ensure a smooth and reliable user experience.