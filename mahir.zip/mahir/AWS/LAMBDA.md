[[aws]]

****15 min lambda timeouts alternative*****:

>Fat Lambda Strategy

A Fat Lambda strategy is used when your task is singular but has a long-running execution time and/or you have heavy hardware requirements. The idea is that you would create a **script** that executes your long process and put it into a **docker container** that's hosted in **Fargate**. Meaning no limits to execution time and access to powerful hardware (How to create a Fat Lambda https://youtu.be/XUp9SHIHU8w)

>>Step Function strategy

A Step Function strategy is used to break down your entire process into smaller steps. Usually, a step function strategy would work for you if your process could have lots of miniature stages linked together instead of a big colossal job attempting to do everything simultaneously. Bear in mind that a "Fat Lambda" can also be triggered by a Step Function (How to create a Step Function


>>>Also another note, remember lambdas can also trigger other lambdas. So you might even be able to have different lambdas run bits of your lambda code. For example, a FOR loop sends off a lot of mini lambdas to run small tasks. You might not even need a Step Function or a Fat Lambda.

If you're stuck on what to choose, follow the below. It will help you reason with your problem.

*Singular Lambda >> Lambda invoke another Lambda? >> Step Functions? >> Fargate (Fat Lambda)?


- Disc space is restricted to **512 MB**.
- The deployment package size is **50 MB** by default.
- There are **128 to 3008 MB** of RAM available.
- The maximum execution timeout for a function is 15 minutes.


> lambda cold start optimize

     use porvision concurrency ( keep specify instance warm)
     optimize code (minimize external depedecy) 
     use lambda layer
     minimize num of library

> how to connect lambda with RDS

     RDS PROXY

> lambda with sqs how handle error

     DEAD LETTER QUE
     CLODWATCH
     Xray
     setup trigger alarm


> 15 min timout solution

     breakdown task in smaller lambda n orchstate in step fucntion 


> lambda code reusuable

     lambda layers

> typr of concureency

     prvisoined
     on demand

> 