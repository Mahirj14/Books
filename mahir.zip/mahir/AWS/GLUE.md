[[aws]]


> Dynamic Frame


```python

import sys   #sys argument (for get resolved method option)
from awsglue.transform import *   #import all class
from awsglue.utils import getResolvedOptions #reading glue job parameters /bookmark
from pyspark.context import  sparkcontext
from awsglue.context import Gluecontext
from awsglue.jobs import job 

sc = sparkcontext.getorcreate()
gluecontext = Gluecontexct (sc)
spark = glueconext.spark_session
job = job(gluecontext)

s3_path: " "

dynamic_frame = glue_context.create_daynamic_frame.from_options(
				frame = dataframe # this only for wrting the data in db
				formate = 'parqet',
				connection_type = "s3",
				connection_option ={"path": s3_path}
)

```


>WHY dynamicframe is best for aws Glue?

- Automatic Schema Inference and Evolution
- Handling Nested and Complex Structures:
- Built-in Integration with AWS Glue Catalog:
- ETL-Specific Operations
- DynamicFrames can handle inconsistent data types within the same column through the `resolveChoice` operation, which provides strategies for resolving type mismatches.
-  relationalize() function for flatten the data in json


import sys
from awsglue.transforms
from awsglue.utils
from pysprak.context from sparkcontext
from awsglu.context from gluecontext
from awsglue.jobs jobs

sc = spark.context
gluecontext = glucontect(sc)
spark = glucontect.spark_session
job = job(glucontext)


import sys
from awsglue.transforms
from awsglue. utils
from pysparkcontext import sparkcontext
from awsglue import glucontext
from awsglue imoprt job

sc = spark.contexct
gluecontect = gluecontect(sc)
spark = glucontexct.spark_session
job = gluecontext(job)

